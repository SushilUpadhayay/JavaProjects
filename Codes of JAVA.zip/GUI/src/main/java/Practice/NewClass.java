
package Practice;
import java.sql.*;
import java.util.*;
public class NewClass {
    public static void main(String[] args) throws Exception
    {
        Scanner input = new Scanner(System.in);
        String choice = null;
        String nm, id, pro;
        do
        {
            try
            {
                Class.forName("com.mysql.cj.jdbc.Driver");
                Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Hello", "root", "5130");
                Statement st = con.createStatement();
                System.out.println("Enter name: ");
                nm = input.nextLine();
                System.out.println("Enter id: ");
                id = input.nextLine();
                System.out.println("Enter program: ");
                pro = input.nextLine();
                String str = "Select * FROM Student WHERE program = '"+pro+"'"; 
                st.executeUpdate(str);
                System.out.println("Details are entered sucessfully");
            }
            catch(Exception e)
            {
                System.out.println("Error"+e.getMessage());
            }
            System.out.println("Do you want to continue?"+"\n"+"If yes then type y and if no then type anything except y:");
            choice = input.nextLine();    
        }while(choice.equals("y"));
    }
    
}
