
package Threading;

class ThreadDem extends Thread {
    public void run() {
        System.out.println("Thread Name: "+Thread.currentThread().getName()+", Thread Priority: "+Thread.currentThread().getPriority());
    }
}

public class ThreadPriority {
    public static void main(String[] args) {
        ThreadDem thread1 = new ThreadDem();
        ThreadDem thread2 = new ThreadDem();
        ThreadDem thread3 = new ThreadDem();
        
        thread1.setPriority(Thread.MIN_PRIORITY); // Set lowest priority
        thread2.setPriority(Thread.NORM_PRIORITY); // Set default priority
        thread3.setPriority(Thread.MAX_PRIORITY); // Set highest priority
        
        thread1.start();
        thread2.start();
        thread3.start();
    }
}
