
package Threading;
class MyThread2 extends Thread
{
    @Override
    public void run()
    {
        int c = 10/0;
        
    }
    
}

public class StackCocept {
    public static void main(String[] args)
    {
        MyThread2 th1 = new MyThread2(); // class thread is a part of the lang pacakage that's why we don't have to import anything.th2 is a reference while it's actual name is Thread - 2
        th1.run(); 
        
    }
    
}
