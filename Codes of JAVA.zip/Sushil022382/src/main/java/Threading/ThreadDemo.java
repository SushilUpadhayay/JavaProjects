
package Threading;
class MyThread extends Thread
{
    @Override
    public synchronized void run() // Here synchronized keyword is used to synchronized the two threads 
    {
        for (int i = 0; i<=10; i++)
        {
            System.out.println(i); 
        }
    }
    
}
public class ThreadDemo {
    public static void main(String[] args) throws Exception
    {
        MyThread th1 = new MyThread(); // class thread is a part of the lang pacakage that's why we don't have to import anything
        MyThread th2 = new MyThread(); // th2 is a reference while it's actual name is Thread - 2
        th1.start(); 
        th1.join();
        th2.start();
        
    }
    
}
