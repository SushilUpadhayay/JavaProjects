
package Threading;
class MyThread3 implements Runnable
{
    /*MyThread3()
    {
        new Thread(this).start();
    }*/
    @Override
    public void run()
    {
       for(int i = 1; i <= 10; i++)
       {
           System.out.println(i);
       }
    }
}
public class WithRunnable {
    public static void main(String[] args)
    {
        MyThread3 th = new MyThread3();
        Thread th1 = new Thread(th); //this can be shorten by using constructor
        th1.start();
        /*
        th.start() we can't do this while shifting the thread into thread pool because 
        neither our class MyThread3 has start() method nor the Runnable interface. If the runnable 
        interface has this start() method then we can do this.
        */
    }
    
    
}
