
package LabSheet2;
import java.net.Socket;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
public class Client {
    public static void main(String[] args) throws Exception
    {
        String Ip = "localhost";
        int port = 9999;
        Socket s = new Socket(Ip, port); // After exection you are connected to the server
        
        String str = "Sushil Upadhayay";
        OutputStreamWriter os = new OutputStreamWriter(s.getOutputStream());
        PrintWriter out = new PrintWriter(os);
        out.println(str);
        os.close();
    }
}
/*
1. In Socket Programming we require a socket in order to connect client to a server
2. Every client needs one socket associated with it. If there are multiple clients then
we need multiple sockets in server side for each client in order to send request to 
server as a server can interact with multiple clients. But remember as a client you only
need one socket even if the server is interacting with multiple clients.
3. While creating a Socket class object you need two things; IP Address of the server and
port number for that specific client. Port number unquinely identifies each process.
4. There are about 0 to 65535 port numbers in which 0 to 1023 are reserved. Therefore we can use
any port number between 1024 to 65535. Since the port number you are mentioning might be
reserved by other process so it is ideal to use "throws" to handle this type of exception.
5. If you are using two machines One for server, one for client then you have to mention 
the port number of the server in the client section as well in Ip address section.Since I am using one machine for both server
and client that's why I mentioned the Ip address as "localhost".
6. "OutputStreamWritter" This class will convert the specified string in our case "Sushil Upadhayay" into a stream
that can be passed through the socket. While creating a object you have to mention where 
you want to pass the data i.e in our case through a socket. So through our output port of the socket
we are sending the data.
7. Now we have converted data into stream and told through where we want to send data. But actually do this we need to create a object of the 
PrintWriter object

*/
