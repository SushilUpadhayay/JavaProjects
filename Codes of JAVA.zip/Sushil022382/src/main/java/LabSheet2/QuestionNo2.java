/*
 WAP to read directly from a URL. [HINT: you may use any URL for reference].
 */
package LabSheet2;
import java.net.URL;
import java.io.BufferedReader;
import java.io.InputStreamReader;

public class QuestionNo2 {
    public static void main(String[] args) throws Exception 
    {
        URL url = new URL("https://www.nec.edu.np/"); 
        BufferedReader reader = new BufferedReader(new InputStreamReader(url.openStream())); // Object of reader class should be passed.InputStreamReader is a child class of Reader Class
        String line;
        while ((line = reader.readLine()) != null) // Reads  characters from the buffer until it encounters a newline character (\n), forming a complete line of text. It then returns that line as a String object.
        {
            System.out.println(line);
        }
        reader.close();
    }
}
// The code fetches the raw HTML content of the website. 