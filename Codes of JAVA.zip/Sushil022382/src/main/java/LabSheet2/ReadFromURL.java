package LabSheet2;
import java.io.*;
import java.net.*;
public class ReadFromURL {
    public static void main(String[] args) {
        try {
            // Create a URL object with the specified URL
            URL url = new URL("http://www.example.com");
            
            // Open a connection to the URL
            URLConnection connection = url.openConnection();
            
            // Create a BufferedReader to read the input stream from the connection
            BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            
            String inputLine;
            // Read lines from the BufferedReader until null (end of stream) is reached
            while ((inputLine = in.readLine()) != null) {
                System.out.println(inputLine);
            }
            
            // Close the BufferedReader
            in.close();
        } catch (IOException e) {
            // Handle potential IOExceptions
            System.out.println("IOException: " + e.getMessage());
        }
    }
}
