/*
WAP to display protocol, authority, host, port, path, query, file name and ref from the URL
&quot;http://example.com:80/docs/books/tutorial&quot; + &quot;/index.html?name=networking#
DOWNLOADING&quot;
*/
package LabSheet2;
import java.net.URL;
public class QuestionNo1 {
    public static void main(String[] args) throws Exception
    {
            URL url = new URL("http://example.com:80/docs/books/tutorial/index.html?name=networking#DOWNLOADING");
            System.out.println("Protocol: "+url.getProtocol());
            System.out.println("Authority: "+url.getAuthority());
            System.out.println("Host: "+url.getHost());
            System.out.println("Port: "+url.getPort());
            System.out.println("Path: "+url.getPath());
            System.out.println("Query: "+url.getQuery());
            System.out.println("File Name: "+url.getFile());
            System.out.println("Ref: "+url.getRef());
            System.out.println("User Info: "+url.getUserInfo());
    }
    
}
