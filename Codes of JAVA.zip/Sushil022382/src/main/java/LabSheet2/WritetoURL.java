package LabSheet2;
import java.io.*;
import java.net.*;

public class WritetoURL {
    public static void main(String[] args) {
        try {
            // Create a URL object for the specified URL
            URL url = new URL("http://www.example.com/cgi-bin/script");
            
            // Open a connection to the URL
            URLConnection connection = url.openConnection();
            
            // Enable output for the connection, which allows sending data to the server
            connection.setDoOutput(true);
            
            // Create a PrintWriter to write data to the output stream of the connection
            PrintWriter out = new PrintWriter(connection.getOutputStream());
            
            // Send data to the server (URL-encoded form parameters)
            out.println("param1=value1&param2=value2");
            
            // Flush the writer to ensure all data is sent
            out.flush();
            
            // Close the writer to release system resources
            out.close();
        } catch (IOException e) {
            // Handle potential IOExceptions
            System.out.println("IOException: " + e.getMessage());
        }
    }
}
