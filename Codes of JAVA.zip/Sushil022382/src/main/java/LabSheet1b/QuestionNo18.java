/*
Create your own exception using throw
*/
package LabSheet1b;

class AccidentException extends Exception // AccidentException.java
{ 
    public AccidentException(String message) 
    {
        super(message);
    }
}

class Car
{
    private String direction; // "NORTH" or "SOUTH"
    private String lane;      // "LEFT" or "RIGHT"

    public Car(String direction, String lane) 
    {
        this.direction = direction;
        this.lane = lane;
    }

    public static void check(Car c1, Car c2) throws AccidentException
    {
        /* The throws keyword is used in a method signature to declare that the method might 
        throw a particular type of exception. It is a way of informing the caller of the method
        that they need to handle this exception.*/
        if (!c1.direction.equals(c2.direction) && c1.lane.equals(c2.lane))
        {
            throw new AccidentException("Accident occurs");
        }
        else
        {
            System.out.println("No accident. Cars are in safe positions.");
        }
    }
}

public class QuestionNo18 {
    public static void main(String[] args) 
    {
        
        Car c1 = new Car("NORTH", "LEFT");
        Car c2 = new Car("SOUTH", "LEFT");

        try
        {
            Car.check(c1, c2);
        }
        catch (AccidentException e)
        {
            System.out.println("Exception: " + e.getMessage());
        }
        System.out.println("Program continues...");
    }
}
