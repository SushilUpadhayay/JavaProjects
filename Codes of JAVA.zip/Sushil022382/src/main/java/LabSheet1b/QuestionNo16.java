/*
Create a program using try and multiple catch statements
 */
package LabSheet1b;

public class QuestionNo16 {
     public static void main(String[] args) 
     {
        int[] numbers = {10, 20, 30};
        int index = 5; // This will cause ArrayIndexOutOfBoundsException
        int denominator = 0; // This will cause ArithmeticException
        
        try
        {
            // Attempt to access an invalid array index
            System.out.println("Accessing array element: " + numbers[index]);
            
            // Attempt to divide by zero
            int result = numbers[0] / denominator;
            System.out.println("Result: " + result);
        } 
        catch (ArrayIndexOutOfBoundsException e)
        {
            // Handle array index out of bounds exception
            System.out.println("Error: Array index out of bounds.");
        } 
        catch (ArithmeticException e)
        {
            // Handle divide by zero exception
            System.out.println("Error: Cannot divide by zero.");
        } 
        catch (Exception e) 
        {
            // Handle any other exceptions
            System.out.println("Error: An unexpected error occurred.");
        }
        
        System.out.println("Program continues...");
    }

}
