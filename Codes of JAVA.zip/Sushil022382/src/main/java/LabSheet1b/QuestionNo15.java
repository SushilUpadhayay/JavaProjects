/*
Create a program using try and catch statements
*/
package LabSheet1b;

public class QuestionNo15 {
    public static void main(String[] args) 
    {
        int numerator = 10;
        int denominator = 0;
        try
        {
            // Attempt to divide by zero
            int result = numerator / denominator;
            System.out.println("Result: " + result);
        } 
        catch (ArithmeticException e) 
        {
            // Handle the divide by zero exception
            System.out.println("Error: Cannot divide by zero.");
        }
        
        System.out.println("Program continues...");
    }
    
}
