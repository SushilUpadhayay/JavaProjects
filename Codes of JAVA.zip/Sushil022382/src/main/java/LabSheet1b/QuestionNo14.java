/*
Illustrate use of Packages
*/
package LabSheet1b;
import java.util.Scanner; // The class Scanner of package utill helps us to take input from user
public class QuestionNo14 {
    public static void main(String[] args)
    {
        Scanner input = new Scanner(System.in);
        int a = input.nextInt();
        System.out.println(a);
        
    }
    
}
