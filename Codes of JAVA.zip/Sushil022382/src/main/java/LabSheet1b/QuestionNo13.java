/*
Illustrate use of Interfaces
*/
package LabSheet1b;
import java.io.*;

// A simple interface
interface In1 
{
  
    // public, static and final
    final int a = 10;

    // public and abstract
    void display();
}

// A class that implements the interface.
class QuestionNo13 implements In1 {
  
    public void display()
    { 
      System.out.println("Sushil Dai"); 
    }

    // Driver Code
    public static void main(String[] args)
    {
        QuestionNo13 t = new QuestionNo13();
        t.display();
        System.out.println(a);
    }
}