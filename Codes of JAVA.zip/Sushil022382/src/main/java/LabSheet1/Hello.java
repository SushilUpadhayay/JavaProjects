
package LabSheet1;

public class Hello {
       public static void QuestionNo13 (String[] args)
        {
    
       System.out.println("Hello World.");
    }
}
