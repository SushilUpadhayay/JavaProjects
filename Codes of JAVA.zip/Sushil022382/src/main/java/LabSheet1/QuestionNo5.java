/*
Illustrate use of command line arguments
*/
package LabSheet1;

public class QuestionNo5 {
    
}
