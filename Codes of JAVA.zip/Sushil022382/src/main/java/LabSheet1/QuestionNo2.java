package LabSheet1;
import java.util.Scanner;

public class QuestionNo2 {
    
    // To check if a number is prime
    public static boolean isPrime(int num) 
    {
        if (num <= 1) {
            return false; // 1 and less are not prime numbers
        }
        for (int i = 2; i <= Math.sqrt(num); ++i) 
        {
            // Condition for nonprime number
            if (num % i == 0) 
            {
                return false;
            }
        }
        return true;
    }

    // To print prime numbers in a given range
    public static void printPrimeRange(int left, int right) 
    {
        if (left >= right) 
        {
            System.out.println("Invalid range!!!");
            return;
        }
        
        System.out.println("Prime numbers between " + left + " and " + right + ":");
        for (int i = left; i <= right; ++i)
        {
            if (isPrime(i)) 
            {
                System.out.println(i);
            }
        }
    }

    public static void main(String[] args) 
    {
        Scanner input = new Scanner(System.in);

        // Prime number verification
        System.out.print("Enter an integer number: ");
        int num = input.nextInt();
        if (isPrime(num))
        {
            System.out.println(num + " is a prime number.");
        } 
        else
        {
            System.out.println(num + " is not a prime number.");
        }

        // Printing prime numbers within a range
        System.out.print("Enter the left extreme of the range: ");
        int left = input.nextInt();
        System.out.print("Enter the right extreme of the range: ");
        int right = input.nextInt();
        printPrimeRange(left, right);
        
        input.close();
    }
}
