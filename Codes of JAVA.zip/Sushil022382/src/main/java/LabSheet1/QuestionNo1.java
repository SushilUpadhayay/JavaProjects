/*
 WAP "Hello World" JAVA
*/
package LabSheet1;
public class QuestionNo1 {
    public static void main(String[] args)
    {
        System.out.println("Hello World");
    }
    
}
