/*
Creates a super class called Figure. Its defines a method called area( ) that
computes the area of an object. The program derives two subclasses from
Figure. The first is Rectangle and the second is Triangle. Each of these
subclasses overrides area( ) so that it returns
*/
package LabSheet1;
class Figure
{
    public double findArea()
    {
        return 0;
    }
}

class Rectangle extends Figure
{
    double length, width;
    Rectangle(double length, double width)
    {
        this.length = length;
        this.width = width;
    }
    
    @Override
    public double findArea()
    {
        return this.length*this.width;
    }
}

class Triangle extends Figure
{
    
    double base, height;
    
    Triangle(double base, double height)
    {
        this.base = base;
        this.height = height;
    }
    
    @Override
    public double findArea()
    {
        return (this.base*this.height*0.5);
    }
    
}


public class QuestionNo8 {
    public static void main(String[] args)
    {
        Rectangle r1 = new Rectangle(5, 6);
        System.out.println("The area of rectangle is: "+r1.findArea()+" square units.");

        Triangle t1 = new Triangle(5, 2);
        System.out.println("The area of circle is: "+t1.findArea()+" square units.");
    }
       
}
