/*
Illustrate a Simple inheritance Using super to Call Super class Constructors
*/
package LabSheet1;
class Animal 
{
    String name;
    // Constructor of Animal class
    Animal(String name) 
    {
        this.name = name;
        System.out.println("Animal constructor called");
    }

    void eat() 
    {
        System.out.println(name + " is eating");
    }
}

class Dog extends Animal 
{
    int age;

    // Constructor of Dog class
    Dog(String name, int age) 
    {
        super(name); // Calls the constructor of Animal class
        this.age = age;
        System.out.println("Dog constructor called");
    }

    void bark() 
    {
        System.out.println(name + " is barking");
    }
}

public class QuestionNo12 
{
    public static void main(String[] args) 
    {
        Dog myDog = new Dog("Buddy", 3);
        myDog.eat();
        myDog.bark();
        System.out.println("My dog's age is " + myDog.age);
    }
}
