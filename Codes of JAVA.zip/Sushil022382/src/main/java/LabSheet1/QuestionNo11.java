/*
Illustrate a simple inheritance.
*/
package LabSheet1;
class Base
{
    public void display()
    {
        System.out.println("In the base class.");
    }
}
class Derived extends Base
{
    public void display2()
    {
        System.out.println("In the derived class.");
    }
}

public class QuestionNo11 {
    public static void main(String[] args)
    {
        Base b = new Base();
        b.display();
        
        Derived d = new Derived();
        d.display(); // Even though the class Derived doesnot has this function it can call it as this method is present in the super class from ehivh it is inheritancing this is called inheritance
        d.display2();
    }
        
            
}
