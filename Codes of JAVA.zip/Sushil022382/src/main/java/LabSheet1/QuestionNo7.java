/*
Illustrate use of Overriding
*/
package LabSheet1;
class Display
{
    public void display()
    {
        System.out.println("In the super class Display.");
    }
}
class Display2 extends Display
{
    @Override
    public void display()
    {
       System.out.println("In the child class Display2.");
    }
}
class Display3 extends Display
{
    @Override
    public void display()
    {
       System.out.println("In the child class Display3.");
    }
}

public class QuestionNo7 {
    public static void main(String[] args)
    {
        Display dp = new Display();
        dp.display(); // In the super class Display.
        
        Display2 dp2 = new Display2();
        dp2.display(); // In the child class Display2.
        
        Display3 dp3 = new Display3();
        dp3.display(); // In the child class Display3.
    }
    
}
