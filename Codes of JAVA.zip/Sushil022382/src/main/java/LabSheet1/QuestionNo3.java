/*
Illustrate use of classes and objects
*/
package LabSheet1;

class Car 
{
    // Properties of the Car class
    private final String make;
    private final String model;
    private final int year;

    // Constructor to initialize the Car object
    public Car(String make, String model, int year) 
    {
        this.make = make;
        this.model = model;
        this.year = year;
    }

    // Method to display the car's details
    public void displayDetails() 
    {
        System.out.println("Car Make: " + make);
        System.out.println("Car Model: " + model);
        System.out.println("Car Year: " + year);
    }
}

public class QuestionNo3 {
    public static void main(String[] args) 
    {
        // Creating objects of the Car class
        Car car1 = new Car("Bugatti", "Chiron", 2017);
        Car car2 = new Car("Ferrari", "12 clindri", 2024);

        // Calling methods on the Car objects
        car1.displayDetails();
        car2.displayDetails();
    }
    
}
