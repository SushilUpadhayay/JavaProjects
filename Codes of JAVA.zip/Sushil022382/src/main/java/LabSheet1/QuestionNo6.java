/*
 Illustrate use of Stream classes to take user’s input
 */
package LabSheet1;
import java.util.Scanner; // input using Scanner class
import java.io.*;
public class QuestionNo6 {
    public static void main(String[] args) throws IOException{
        
        // using Scanner for input
        Scanner input = new Scanner(System.in); // Making an object of Scanner class
        
        System.out.println("Input a integer: ");
        int a = input.nextInt(); // for a integer input
        System.out.println("Integer input using Scanner class: "+a);
        
        /*
        The Scanner class does not properly reads a string input is due to the behavior of nextInt() 
        and nextDouble() methods. These methods do not consume the newline character after the number, causing nextLine() to read 
        the leftover newline instead of waiting for the user input.
        */
        
        // Consuming the leftover newline or you can take input of string at first
        input.nextLine(); 
        System.out.print("Input a string: ");
        String str = input.nextLine(); // for a String input
        System.out.println("String input usig Scanner class: "+str);
        
        
        System.out.println("Input a double: ");
        double db = input.nextDouble(); // for double input
        System.out.println("Double input usig Scanner class: "+db);
        
        // Using BufferedReader for input
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in)); // Making an object of BufferedReader class
        System.out.println("Input a integer: ");
        int b = Integer.parseInt(reader.readLine()); // for a integer input
        System.out.println("Integer input using BufferedReader class: "+b);
        
        System.out.println("Input a double value: ");
        double db2 = Double.parseDouble(reader.readLine()); // for a Double input
        System.out.println("Double input usig BufferedReader class: "+db2);

        System.out.println("Input a string: ");
        String str2 = reader.readLine(); // for a String input
        System.out.println("String input usig BufferedReader class: "+str2);
    }
    
}
