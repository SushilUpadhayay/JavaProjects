/*
Illustrate use of constructors
*/
package LabSheet1;

class Example
{
    int a = 0;
    Example(int a) // Construcytor is used for initialization of variables
    {
         this.a = a;
    }
    public void display()
    {
        System.out.println("a: "+a);
    }
}

public class QuestionNo4 
{
    public static void main(String[] args)
    {
        Example ex = new Example(5);
        ex.display(); // Outputs a: 5    
    }
    
}
