/*
Create a program illustrates the Overloading
*/
package LabSheet1;

public class QuestionNo10 
{
    int sum = 0;
    public void Method(int a)
    {
        System.out.println("Sum is: "+(sum+a));
    }
    
    public void Method(int a, int b)
    {
        System.out.println("Sum is: "+(sum+a+b));
    }
 
    public void Method(int a, int b, int c)
    {
        System.out.println("Sum is: "+(sum+a+b+c));
    }
    
    public static void main(String[] args)
    {
        QuestionNo10 obj = new QuestionNo10();
        obj.Method(5);
        obj.Method(5, 2);
        obj.Method(5, 2, 1);
        
    }
    
}
