/*
Illustrate use of Interfaces
*/
package LabSheet1;


public class Draft
{
        public static void QuestionNo13 (String[] args)
        {
    
       System.out.println("Hello World.");
    }
}

