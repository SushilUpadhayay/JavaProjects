
package GUIprogramming;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;

public class GridBagLayoutExample {

    public static void main(String[] args) {
        // Create a JFrame
        JFrame frame = new JFrame("GridBagLayout Example");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 300);

        // Create a JPanel with GridBagLayout
        JPanel panel = new JPanel(new GridBagLayout());

        // Create GridBagConstraints for positioning components
        GridBagConstraints gbc = new GridBagConstraints();

        // Button 1
        JButton button1 = new JButton("Button 1");
        gbc.gridx = 0; // x co-ordinate
        gbc.gridy = 0; // y-co-ordinate
        gbc.gridwidth = 1;
        panel.add(button1, gbc);

        // Button 2
        JButton button2 = new JButton("Button 2");
        gbc.gridx = 1;
        gbc.gridy = 0;
        gbc.gridwidth = 1;
        panel.add(button2, gbc);

        // Button 3
        JButton button3 = new JButton("Button 3");
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 2;
        panel.add(button3, gbc);

        // Button 4
        JButton button4 = new JButton("Button 4");
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 1;
        panel.add(button4, gbc);

        // Button 5
        JButton button5 = new JButton("Button 5");
        gbc.gridx = 1;
        gbc.gridy = 2;
        gbc.gridwidth = 1;
        panel.add(button5, gbc);

        // Add the panel to the frame
        frame.add(panel);

        // Make the frame visible
        frame.setVisible(true);
    }
}

