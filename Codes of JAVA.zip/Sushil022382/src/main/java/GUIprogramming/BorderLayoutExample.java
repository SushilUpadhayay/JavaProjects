
package GUIprogramming;
import java.awt.*;
import javax.swing.*;


public class BorderLayoutExample {
    public static void main(String[] args) {
        JFrame f = new JFrame("layout"); // Create a Frame object with a title
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // closes the frame when I press the cross button on top
        f.setSize(300, 200);  // Set the size of the frame
        f.setLayout(new BorderLayout());  // Set the layout manager for the frame to BorderLayout

        // Add components to the frame in different regions of the BorderLayout
        f.add(new Button("Hello"),   BorderLayout.NORTH); // Adds hello at the north region of the frame
        f.add(new Button("World"),   BorderLayout.SOUTH);
        f.add(new Button("It's"),    BorderLayout.EAST);
        f.add(new Button("Sushil"),  BorderLayout.WEST);
        f.add(new Button("Namaste"), BorderLayout.CENTER);
       

        // Make the frame visible
        f.setVisible(true);
    }
}