
package GUIprogramming;
import java.awt.CardLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class CardLayoutExample{

    public static void main(String[] args) {
        // Create the frame
        JFrame frame = new JFrame("CardLayout Example");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 300);

        // Create the CardLayout and the panel that uses it
        CardLayout cardLayout = new CardLayout();
        JPanel cardPanel = new JPanel(cardLayout);

        // Create and add the cards
        JPanel card1 = new JPanel();
        card1.add(new JButton("Card 1"));

        JPanel card2 = new JPanel();
        card2.add(new JButton("Card 2"));

        JPanel card3 = new JPanel();
        card3.add(new JButton("Card 3"));

        cardPanel.add(card1, "1");
        cardPanel.add(card2, "2");
        cardPanel.add(card3, "3");

        // Create and add navigation buttons
        JButton btnNext = new JButton("Next");
        JButton btnPrevious = new JButton("Previous");

        // ActionListener for "Next" button
        btnNext.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            cardLayout.next(cardPanel);
        }
        });

        // ActionListener for "Previous" button
        btnPrevious.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            cardLayout.previous(cardPanel);
        }
        });

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(btnPrevious);
        buttonPanel.add(btnNext);

        // Add panels to the frame
        frame.add(cardPanel, "Center");
        frame.add(buttonPanel, "South");

        // Display the frame
        frame.setVisible(true);
    }
}
/* 
java.awt.event.ActionEvent: Represents an event that describes a user action (such as clicking a button) within an 
AWT/Swing application.
java.awt.event.ActionListener: Defines the interface for receiving action events. It has a single method 
actionPerformed(ActionEvent e) that gets invoked when an action occurs.
*/