
package ExceptionHandling;
import java.util.*;

public class OurThrowAndDefaultCatch {
    public static void main(String[] args)
    {
    int balance = 5000;
    int withdrawlAmount = 6000;
    if (balance<withdrawlAmount)
    {
        throw new ArithmeticException("Insufficient Balance.");
    }
    balance = balance - withdrawlAmount;
    System.out.println("Transaction Completed Sucesfully");
    }
}
/*
In Java, you cannot throw an exception using throw followed by just the exception type. Instead, you need to create a new instance of the exception using the new keyword. 
*/