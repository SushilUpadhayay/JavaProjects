
package ExceptionHandling;

public class DefaultThrowAndOurCatch {
    public static void main(String[] args)
    {
        try
        {
            System.out.println("Quotient:"+3/0);
            
        }
        catch(ArithmeticException e)
        {
            System.out.println("Exception: "+e.getMessage());
        }
        finally
        {
            System.out.println("HelloWorld");
        }
    }
    
}
