
package RMIprac;
import RMIprac.AddImp;
import java.rmi.Naming;
import java.rmi.registry.LocateRegistry;
public class Server {
    public static void main(String[] args) throws Exception
    {
        LocateRegistry.createRegistry(1099);
        AddImp obj = new AddImp(); 
        Naming.rebind("ADD", obj); // Assigns caption to the object 'obj' to ADD; static object belonging to Naming class
        System.out.println("Server started");
    }
}
/*
1. As the server contains the implementation we are creating object of the class which is implementing the interface
2. Now we have to register the object in the RMI registery
3. Server is executed independentaly so we are creating a main object inside it

*/