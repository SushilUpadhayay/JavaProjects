
package RMIprac;
import java.rmi.server.UnicastRemoteObject;

public class AddImp extends UnicastRemoteObject implements AddI {
    public AddImp() throws Exception
    {
        super(); // to call the constructor of the UniCastRemoteObject
    }
    @Override
    public int Add(int x, int y)
    {
        return x+y;
    }
    
}
/*
1. Since we have to later create stub and skeleton we have to extends this above class using UnicastRemoteObject

*/
/*
/*
Requirements:
1. Client machine will have stack segement in one JVM 
2. Server machine will have heap segemnt in other JVM
3. Client will have something called Stub whereas Server will have something called Skeleton
4. So there is going to be aggrement between client and server on the basis of Stub and Skeleton

How to do it?
1. Ceate a remote interface
2. Is to provide implementation of this remote interface
6. Create  server
7. Create client
7. Compile all the java files for  these files use cmd and command javac *.java 
8. Create stub and skeleton, no need in the java version greater than 5.0
 Create and start Registry: If there are lots of objects or clients then to uniquely identifiy them there global name are registered in the registry

*/