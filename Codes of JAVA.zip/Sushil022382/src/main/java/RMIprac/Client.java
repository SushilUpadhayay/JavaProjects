
package RMIprac;
import java.rmi.Naming;
public class Client {
    public static void main(String[] args) throws Exception
    {
        AddI obj = (AddI)Naming.lookup("ADD");// But we know the interface; type casting because we don't want the object of a class but we want the object of interface
        int i = obj.Add(5, 4); // but we don't know where this function is at
        System.out.println(i);
    }    
}
