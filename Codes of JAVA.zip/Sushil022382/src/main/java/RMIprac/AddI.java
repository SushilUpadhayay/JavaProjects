package RMIprac;
import java.rmi.Remote;

public interface AddI extends Remote {
 public int Add(int x, int y) throws Exception;
}

/* 
1. To make this interface a remote one we are extending it using Remote
*/