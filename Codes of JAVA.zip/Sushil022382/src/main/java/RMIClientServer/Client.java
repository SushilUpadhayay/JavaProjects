
package RMIClientServer;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.Naming;

public class Client {
    public static void main(String[] args) throws Exception{
            // Look up the remote object in the registry
            Hello stub = (Hello) Naming.lookup("Hello");
            
            // Call the remote method
            String response = stub.sayHello();
            System.out.println("Response: " + response);

    }
}

