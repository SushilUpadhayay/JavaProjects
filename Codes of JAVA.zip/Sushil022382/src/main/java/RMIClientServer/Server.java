
package RMIClientServer;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.Naming;

public class Server {
    public static void main(String[] args) {
        try {
            // Start the RMI registry programmatically
            LocateRegistry.createRegistry(1099);

            // Create an instance of the implementation class
            HelloImpl obj = new HelloImpl();
            
            // Bind the remote object's stub in the registry
            Naming.rebind("Hello", obj);
            
            System.out.println("Server ready");
        } catch (Exception e) {
            System.err.println("Server exception: " + e.toString());
            e.printStackTrace();
        }
    }
}
