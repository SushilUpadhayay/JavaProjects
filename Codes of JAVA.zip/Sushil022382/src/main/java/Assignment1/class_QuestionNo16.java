/*
Define a superclass Animal with a method makeSound(). Implement subclasses Dog and Cat that
override this method to make different sounds.
*/
package Assignment1;
class Animal 
{
    public void makeSound() 
    {
        System.out.println("Animal makes a sound");
    }
}

class Dog extends Animal 
{
    @Override
    public void makeSound() 
    {
        System.out.println("Dog barks");
    }
}

class Cat extends Animal 
{
    @Override
    public void makeSound() 
    {
        System.out.println("Cat meows");
    }
}

public class class_QuestionNo16 
{
    public static void main(String[] args) 
    {
        Animal animal1 = new Dog();
        Animal animal2 = new Cat();

        animal1.makeSound(); 
        animal2.makeSound(); 
    }
}
