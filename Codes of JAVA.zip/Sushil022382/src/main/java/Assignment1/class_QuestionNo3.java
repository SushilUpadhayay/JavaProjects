/*
Create a superclass Shape with methods to calculate area and perimeter. Then, create
subclasses Rectangle and Circle inheriting from Shape and override the area and perimeter
methods accordingly.
 */
package Assignment1;

abstract class Shape{
    
    public abstract double findArea();
    public abstract double findPerimeter();
  
}

class Rectangle2 extends Shape{  // I set the name of this class to Rectangle2 not Rectangle because in the 
                                //  package comp2d.Sushil022382 there is already a class Rectangle and because of the
                               //  affect of that class I encountred with errors
    double length, width;
    Rectangle2(double length, double width)
    {
        this.length = length;
        this.width = width;
    }
    
    @Override
    public double findArea()
    {
        return this.length*this.width;
    }
    
    @Override
    public double findPerimeter()
    {
        return 2*(this.length + this.width);
    } 
}

class Circle extends Shape{
    
    double radius;
    
    Circle(double radius)
    {
        this.radius = radius;
    }
    
    @Override
    public double findArea()
    {
        return Math.PI*Math.pow(this.radius, 2);
    }
    
    @Override
    public double findPerimeter()
    {
        return 2*Math.PI*this.radius;
    } 
}

public class class_QuestionNo3 {
    public static void main(String[] args)
    {
        Rectangle2 r1 = new Rectangle2(5, 6);
        System.out.println("The area of rectangle is: "+r1.findArea()+" square units.");
        System.out.println("The perimeter of rectangle is: "+r1.findPerimeter()+" units.");
     
        Circle c1 = new Circle(5);
        System.out.println("The area of circle is: "+c1.findArea()+" square units.");
        System.out.println("The perimeter of circle is: "+c1.findPerimeter()+" units.");
 
    }
    
 }

