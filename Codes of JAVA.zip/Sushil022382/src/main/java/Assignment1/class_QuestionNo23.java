/*
Design a generic class Pair that stores two objects of any type. Implement methods to get and
set the objects in the pair.
 */
package Assignment1;
class Pair<T, U> // T and U will going to be replaced by datatypes during creation of objects of this class
{
    private T A;
    private U B;

    // Constructor
    public Pair(T A, U B) 
    {
        this.A = A;
        this.B = B;
    }

    
    public T getFirst() 
    {
        return A;
    }

    // Method to get the second object
    public U getSecond() 
    {
        return B;
    }

}

public class class_QuestionNo23 
{
    public static void main(String[] args) 
    {
        Pair<Integer, String> pair = new Pair<>(10, "Hello");
        System.out.println("A is: " + pair.getFirst());
        System.out.println("B is: " + pair.getSecond());
    }
}
