/*
Define an interface Shape with methods to calculate area and perimeter. Implement classes
Rectangle and Circle that implement this interface and demonstrate polymorphism by invoking
these methods on objects of both classes.
*/
package Assignment1;
abstract class Shape1{
    
    public abstract double findArea();
    public abstract double findPerimeter();
  
}
class Rectangle3 extends Shape1{  // I set the name of this class to Rectangle3 not Rectangle because in the 
                                //  package comp2d.Sushil022382 there is already a class Rectangle, class Rectangle2 and because of the
                               //  affect of that class I encountred with errors
    double length, width;
    Rectangle3(double length, double width)
    {
        this.length = length;
        this.width = width;
    }
    
    @Override
    public double findArea()
    {
        return this.length*this.width;
    }
    
    @Override
    public double findPerimeter()
    {
        return 2*(this.length + this.width);
    } 
}

class Circle1 extends Shape1{     // I set the name of this class to Circle1 not Circle because in the 
                                //  package comp2d.Sushil022382 there is already a class Circle and because of the
                               //  affect of that class I encountred with errors
    
    double radius;
    
    Circle1(double radius)
    {
        this.radius = radius;
    }
    
    @Override
    public double findArea()
    {
        return Math.PI*Math.pow(this.radius, 2);
    }
    
    @Override
    public double findPerimeter()
    {
        return 2*Math.PI*this.radius;
    } 
}

public class class_QuestionNo8 {
    public static void main(String[] args)
    {
        Rectangle3 r1 = new Rectangle3(5, 6);
        System.out.println("The area of rectangle is: "+r1.findArea()+" square units.");
        System.out.println("The perimeter of rectangle is: "+r1.findPerimeter()+" units.");
     
        Circle1 c1 = new Circle1(5);
        System.out.println("The area of circle is: "+c1.findArea()+" square units.");
        System.out.println("The perimeter of circle is: "+c1.findPerimeter()+" units.");
 
    }
    
 }
