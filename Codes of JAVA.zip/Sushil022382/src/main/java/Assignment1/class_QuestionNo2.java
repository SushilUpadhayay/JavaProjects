/*
Write a program in Java with class Rectangle with the data fields width, length, area and color.
The length, width and area are of double type and color is of string type .The methods are set_
length () , set_width (), set_ color(), and find_ area (). Create two object of Rectangle and
compare their area and color. If area and color both are same for the objects then display
“Matching Rectangles” otherwise display “Non matching Rectangle”.
 */
package Assignment1;

class Rectangle {
    
    String color;
    double length, width, area;
    
    // Method 1 
    public void setLength(double length)
    {
        this.length = length;
    } 
    
    // Method 2 
    public void setWidth(double width)
    {
        this.width = width;
    } 
    
    // Method 3 
    public void setColor(String color)
    {
        this.color = color;
    } 
    
    // Method 4
    public void findArea()
    {
        this.area = this.length*this.width;
    } 
    
    // Method 5 to check similarities between two objects
    public void checkRectangle(Rectangle r1, Rectangle r2)
    {
        if( r1.area == r2.area && r1.color.equals(r2.color))
        {
            System.out.println("Non-matching Rectangles!!!!!!.");
        }
        else
        {
            System.out.println("Matching Rectangles!!!!!!.");
        }
    }    
 }

public class class_QuestionNo2 {
    public static void main(String[] args)
    {
        Rectangle r1 = new Rectangle();
        Rectangle r2 = new Rectangle();
        Rectangle r3 = new Rectangle();
        r1.setColor("Red");
        r1.setLength(5);
        r1.setWidth(6);
        r1.findArea();
        
        r2.setColor("Red");
        r2.setLength(5);
        r2.setWidth(6);
        r2.findArea();
        
        r3.checkRectangle(r1, r2); // Should print 'Matching Rectangles!!!!!!'
    }
    
}
