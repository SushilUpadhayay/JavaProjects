/*
Write a program in Java to create a stack class with push() and pop () methods. Create two
objects of stack with 10 data item in both. Compare the top elements of both stack and print the
comparison result.
*/
package Assignment1;
class Stack 
{
    private final int maxSize;
    private final int[] stackArray;
    private int top;

    public Stack(int maxSize) 
    {
        this.maxSize = maxSize;
        stackArray = new int[maxSize];
        top = -1;
    }
    public void push(int element) 
    {
        if (top == maxSize - 1) 
        {
            System.out.println("Stack is full. Cannot push element.");
        } 
        else 
        {
            stackArray[++top] = element;
        }
    }

    public int pop() 
    {
        if (top == -1) 
        {
            System.out.println("Stack is empty. Cannot pop element.");
            return -1;
        }
        else 
        {
            return stackArray[top--];
        }
    }

    public int peek() 
    {
        if (top == -1) 
        {
            System.out.println("Stack is empty. Cannot peek element.");
            return -1;
        } 
        else 
        {
            return stackArray[top];
        }
    }
}

public class class_QuestionNo13 
{
    public static void main(String[] args) 
    {
        // Create two stack objects with 10 data items in each
        Stack stack1 = new Stack(10);
        Stack stack2 = new Stack(10);

        // Push some elements into stack1
        for (int i = 0; i < 10; i++) 
        {
            stack1.push(i);
        }

        // Push some elements into stack2
        for (int i = 0; i < 10; i++) 
        {
            stack2.push(i + 5);
        }

        // Compare the top elements of both stacks
        int topElementStack1 = stack1.peek();
        int topElementStack2 = stack2.peek();

        // Print the comparison result
        if (topElementStack1 == topElementStack2) 
        {
            System.out.println("Top elements of both stacks are equal: " + topElementStack1);
        } 
        else 
        {
            System.out.println("Top elements of both stacks are not equal.");
            System.out.println("Top element of stack1: " + topElementStack1);
            System.out.println("Top element of stack2: " + topElementStack2);
        }
    }
}

