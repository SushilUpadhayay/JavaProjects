/*
Create a list of integers and use lambda expressions to perform operations like filtering even
numbers, mapping them to their squares, and reducing them to find the sum.
*/
package Assignment1;
import java.util.Arrays;
import java.util.List;

public class class_QuestionNo24
{
    public static void main(String[] args) 
    {
        // Creating a list of integers
        List<Integer> numbers = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10);

        
        List<Integer> evenNumbers = numbers.stream() // Filter even numbers using Lamda function
                .filter(num -> num % 2 == 0)
                .toList();

        List<Integer> squares = evenNumbers.stream() // // Map each even number to its square
                .map(num -> num * num)
                .toList();

        int sumOfSquares = squares.stream() // Reduce to find the sum of squares
                .reduce(0, Integer::sum);

        // Print the result
        System.out.println("Even numbers: " + evenNumbers);
        System.out.println("Squares of even numbers: " + squares);
        System.out.println("Sum of squares of even numbers: " + sumOfSquares);
    }
}
