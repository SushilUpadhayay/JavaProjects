/*
Create a Java program to calculate the area of a circle given its radius. Use the 'Math.PI'
constant and the '*'operator.
*/
package Assignment1;
import java.util.Scanner;
public class IO_QuestionNo13 {
    public static void main(String[] args)
    {
        Scanner input = new Scanner(System.in);
        System.out.print("Enter radius of a circle: ");
        double r = input.nextInt();
        System.out.print("The area of a circle: "+(Math.PI*Math.pow(r, 2))+" square units.");
    }
    
}
