/*
Model a bookstore system with classes such as Book, Author, and Bookstore. Implement a
relationship where a bookstore contains multiple books, and each book is associated with one
or more authors.
*/
package Assignment1;

class Author 
{
    private String name;
    private int age;

    public Author(String name, int age) 
    {
        this.name = name;
        this.age = age;
    }
    public String getName()
    {
        return this.name;
    }
    public int getAge()
    {
        return this.age;
    }
}

class Book 
{
    private String title;
    private Author[] authors;
    private int authorCount;

    public Book(String title, int maxAuthors) 
    {
        this.title = title;
        this.authors = new Author[maxAuthors];
        this.authorCount = 0;
    }

    public void addAuthor(Author author) 
    {
        if (authorCount < authors.length) // authors.length returns the size of the array authors
        {
            authors[authorCount++] = author;
        }
        else 
        {
            System.out.println("Cannot add more authors to the book. Maximum capacity reached.");
        }
    }
    public String getName()
    {
        return this.title;
    }
    public Author[] getAuthors()
    {
        return this.authors;
    }
    
}

class Bookstore 
{
    private String name;
    private Book[] books;
    private int bookCount;

    public Bookstore(String name, int maxBooks) 
    {
        this.name = name;
        this.books = new Book[maxBooks];
        this.bookCount = 0;
    }

    public void addBook(Book book) 
    {
        if (bookCount < books.length) 
        {
            books[bookCount++] = book;
        }
        else 
        {
            System.out.println("Cannot add more books to the bookstore. Maximum capacity reached.");
        }
    }
    public String getName()
    {
        return this.name;
    }
    public Book[] getBooks()
    {
        return this.books;
    }
}
public class class_QuestionNo11
{
    public static void main(String[] args) 
    {
        // Create authors
        Author author1 = new Author("Sushil Upadhayay", 25);
        Author author2 = new Author("Robair Aakash", 26);
        Author author3 = new Author("Aakash Sharma", 21);

        // Create books
        Book book1 = new Book("Quantum Mechanics", 2);
        book1.addAuthor(author1);
        book1.addAuthor(author2);
        Book book2 = new Book("Principle of Physics", 1);
        book2.addAuthor(author2);

        // Create a bookstore
        Bookstore bookstore = new Bookstore("Bookstore of NEC", 5);
        bookstore.addBook(book1);
        bookstore.addBook(book2);
        
        // Retrieve and print information about the bookstore
        System.out.println("Bookstore Name: " + bookstore.getName());
        Book[] books = bookstore.getBooks();
        for (Book book : books) // ChatGpt help
        {
            if (book != null) 
            {
              System.out.println("Book Title: " + book.getName());
              Author[] authors = book.getAuthors();
              System.out.println("Authors:");
              for (Author author : authors) 
              {
                if (author != null) 
                 System.out.println("- " + author.getName() + " (Age: " + author.getAge() + ")");
              }
            }
        }
    }
}
