/*
Develop a Java program to print the first 10 even numbers using for loop.
*/
package Assignment1;

public class IO_QuestionNo7 {
    public static void main(String[] args)
    {
       for(int i = 1;i<=10;i++)
       {
            System.out.print(2*i+"\t");  
       }
    }   
}
