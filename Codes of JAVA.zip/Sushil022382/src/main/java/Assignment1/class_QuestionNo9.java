/*
Design a class Employee with abstract method calculateSalary(). Implement subclasses
FullTimeEmployee and PartTimeEmployee that override this method to calculate the salary
differently based on employment type.
*/
package Assignment1;
abstract class Employee
{
    double salary_rate, hours;
    public abstract void salary(double salary_rate, double hours);
}
class FullTimeEmployee extends Employee
{
    @Override
    public void salary(double salary_rate, double hours)
    {
        System.out.println("The salary of the worker is: "+(this.salary_rate*this.hours));
    }
            
}
class PartTimeEmployee extends Employee
{
    @Override
    public void salary(double salary_rate, double hours)
    {
        System.out.println("The salary of the worker is: "+(this.salary_rate*this.hours));
    }
            
}
public class class_QuestionNo9 {
    public static void main(String[] args)
    {
        FullTimeEmployee f = new FullTimeEmployee();
        System.out.println("The salary of a full time employee worker is: ");
        f.salary(200, 52);
        PartTimeEmployee p = new PartTimeEmployee();
        System.out.println("The salary of a part time employee worker is: ");
        p.salary(150, 47);
        
    }
    
}
