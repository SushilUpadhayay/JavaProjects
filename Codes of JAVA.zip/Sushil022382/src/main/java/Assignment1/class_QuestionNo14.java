/*
Extend the bookstore example with a Library class. Implement a relationship where a library has
multiple bookstores, and each bookstore has multiple books.
*/
package Assignment1;
class Library 
{
    private String name;
    private Bookstore[] bookstores;
    private int bookstoreCount;

    public Library(String name, int maxBookstores) 
    {
        this.name = name;
        this.bookstores = new Bookstore[maxBookstores];
        this.bookstoreCount = 0;
    }

    public void addBookstore(Bookstore bookstore) 
    {
        if (bookstoreCount < bookstores.length) 
        {
            bookstores[bookstoreCount++] = bookstore;
        }
        else 
        {
            System.out.println("Cannot add more bookstores to the library. Maximum capacity reached.");
        }
    }
    public String getName()
    {
        return this.name;
    }
    public Bookstore[] getBookstore()
    {
        return this.bookstores;
    }

}
public class class_QuestionNo14 
{
    public static void main(String[] args) 
    {
        Book book1 = new Book("Book 1", 2);
        Book book2 = new Book("Book 2", 1);
        
        Bookstore bookstore1 = new Bookstore("Bookstore 1", 3);
        bookstore1.addBook(book1);
        bookstore1.addBook(book2);
                
        Bookstore bookstore2 = new Bookstore("Bookstore 2", 2);
        bookstore2.addBook(book2);

        Library library = new Library("Library", 2);
        library.addBookstore(bookstore1);
        library.addBookstore(bookstore2);

        // Retrieve and print information about the library and its bookstores
        System.out.println("Library Name: " + library.getName());
        Bookstore[] bookstores = library.getBookstore();
        for (Bookstore bs : bookstores) 
        {
            if (bs != null) 
            {
                System.out.println("Bookstore Name: " + bs.getName());
                Book[] books = bs.getBooks();
                for (Book book : books) 
                {
                    if (book != null) 
                        System.out.println("Book Title: " + book.getName());  
                }
            }
        }
    }
}
