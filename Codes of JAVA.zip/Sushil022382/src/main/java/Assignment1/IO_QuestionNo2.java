/*
Write a program in Java to find the result of following expression (Assume a = 10, b = 5)

i) (a << 2) + (b << 2) 
ii) (a<0) | | (b < 0)
iii) (a + b * 100) / 10
iv) a & b
*/
package Assignment1;


public class IO_QuestionNo2 {
    public static void main(String[] args) {
        int a = 10, b = 5;
        System.out.println("The output of the expression ((a << 2) + (b << 2)) is:"+ (a << 2) + (b << 2) );
        System.out.println("The output of the expression ((a<0) | | (b < 0)) is:"+ ((a<0)||(b<0)) );
        System.out.println("The output of the expression ((a + b * 100) / 10)  is:"+ ((a + b * 100) / 10) );
        System.out.println("The output of the expression (a & b) is:"+ (a & b) );
 
    }
    
}
