/*
Create a Java program that prompts the user to enter their name and age, and then prints out a
message using the input values.
*/
package Assignment1;

import java.util.Scanner;

public class IO_QuestionNo3 {
    public static void main(String[] args)
    {
        Scanner input = new Scanner(System.in);
        System.out.print("Enter your name: ");
        String name = input.nextLine();
        System.out.print("Enter your age: ");
        int age = input.nextInt();
        System.out.println("You name and age is: "+name+" and "+age);
        
    }
}
