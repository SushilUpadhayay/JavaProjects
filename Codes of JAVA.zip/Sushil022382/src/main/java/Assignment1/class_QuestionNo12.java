/*
Consider trunk calls of a telephone exchange. A trunk call can be ordinary, urgent or lightning
call. The charges depend on the duration and the type of the call. Write a program-using
concept of polymorphism in Java to calculate the charges.
*/
package Assignment1;
// Base class for trunk calls
abstract class TrunkCall 
{
    protected double duration; // Duration of the call, protected not private as I am going to access it from sub class

    public TrunkCall(double duration) 
    {
        this.duration = duration;
    }
    public abstract double calculateCharges();
}

class OrdinaryTrunkCall extends TrunkCall 
{
    private final double rate_per_min = 0.5; // Rate per minute for ordinary calls

    public OrdinaryTrunkCall(double duration) 
    {
        super(duration); // calling constructor of the java super class and passing argument 
    }

    @Override
    public double calculateCharges() 
    {
        return duration * rate_per_min;
    }
}


class UrgentTrunkCall extends TrunkCall 
{
    private final double rate_per_min = 1.0; // Rate per minute for urgent calls

    public UrgentTrunkCall(double duration) 
    {
        super(duration);
    }

    @Override
    public double calculateCharges() 
    {
        return duration * rate_per_min;
    }
}


class LightningTrunkCall extends TrunkCall 
{
    private final double rate_per_min = 1.5; // Rate per minute for lightning calls

    public LightningTrunkCall(double duration) 
    {
        super(duration);
    }

    @Override
    public double calculateCharges() 
    {
        return duration * rate_per_min;
    }
}

public class class_QuestionNo12
{
    public static void main(String[] args) 
    {
        
        // Create trunk calls of different types
        TrunkCall ordinaryCall = new OrdinaryTrunkCall(10); // Duration in minutes
        TrunkCall urgentCall = new UrgentTrunkCall(5);
        TrunkCall lightningCall = new LightningTrunkCall(8);

        // Calculate charges for each type of call and print the results
        System.out.println("Charges for Ordinary Call: $" + ordinaryCall.calculateCharges());
        System.out.println("Charges for Urgent Call: $" + urgentCall.calculateCharges());
        System.out.println("Charges for Lightning Call: $" + lightningCall.calculateCharges());
    }
}

