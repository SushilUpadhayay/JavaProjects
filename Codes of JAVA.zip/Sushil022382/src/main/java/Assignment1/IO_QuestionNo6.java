/*
Write a Java program to check if a given number is a prime number
*/
package Assignment1;
import java.util.Scanner;
public class IO_QuestionNo6 {
    public static void main(String[] args)
    {
        Scanner input = new Scanner(System.in);
        System.out.print("Enter a number(must not be negative, character, string or boolean): ");
        int num = input.nextInt();
        boolean flag = false;
        for (int i = 2; i <= num/2; ++i) 
        {
            // Condition for nonprime number
            if (num % i == 0) 
            {
                flag = true;
                break;
            }
        }
        if (!flag)
            System.out.println(num + " is a prime number.");
        else
            System.out.println(num + " is not a prime number.");
    }
}
