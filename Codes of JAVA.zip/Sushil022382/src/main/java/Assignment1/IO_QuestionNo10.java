/*
Write a program in Java to find AxB where A is a matrix of 3x3 and B is a matrix of 3X4.
*/
package Assignment1;
import java.util.Scanner;

public class IO_QuestionNo10 {
    static void getMatrix(int[][] A, int[][] B)
    {
        Scanner input = new Scanner(System.in);
       
        // Take input of the matrix A
        for(int i = 0; i<3;i++)
        {
            for(int j = 0; j<3;j++)
            {
                System.out.print("Enter A"+"["+i+"]"+"["+j+"]th element: ");
                A[i][j] = input.nextInt(); 
                
            }
        }
        
        // Take input of the matrix B
        for(int i = 0; i<3;i++)
        {
            for(int j = 0; j<4;j++)
            {
                System.out.print("Enter B"+"["+i+"]"+"["+j+"]th element: ");
                B[i][j] = input.nextInt(); 
            }
        
        }
    }
    
    static void displayMatrix(int[][] A, int[][] B)
    {
        // Display matrix A
        System.out.println("The matrix A is as follow: ");
        for(int i = 0; i<3;i++)
        {
            for(int j = 0; j<3;j++)
            {
               System.out.print(A[i][j]+"\t");
            }
            System.out.println();
        }
        
        // Display matrix B
        System.out.println("The matrix B is as follow: ");
        for(int i = 0; i<3; i++)
        {
            for(int j = 0;j<4;j++)
            {
               System.out.print(B[i][j]+"\t");
            }
            System.out.println();
        }
    }
    static void sumDisplay(int[][] A, int[][] B)
    {
        int[][] sum = new int[3][4];
        for (int i = 0; i < 3; i++)
        {
            for (int j = 0; j < 4; j++) 
            {
                for (int k = 0; k < 3; k++)
                {
                    sum[i][j] += A[i][k] * B[k][j];
                }
            }
        }
        
        // Display matrix sum
        System.out.println("The resultant matrix sum is as follow: ");
        for(int i = 0; i<3; i++)
        {
            for(int j = 0;j<4;j++)
            {
               System.out.print(sum[i][j]+"\t");
            }
            System.out.println();
        }
    }
    public static void main(String[] args)
    {
        int[][] A = new int[3][3];
        int[][] B = new int[3][4];
        getMatrix(A, B);
        displayMatrix(A, B);
        sumDisplay(A, B);
    }

}
