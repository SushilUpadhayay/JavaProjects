/*
Implement a class Calculator with overloaded methods for addition, subtraction, multiplication,
and division operations accepting different data types as parameters.
*/
package Assignment1;
class Calculator 
{
    // Addition
    public int add(int a, int b) 
    {
        return a + b;
    }

    public double add(double a, double b) 
    {
        return a + b;
    }

    // Subtraction
    public int subtract(int a, int b) 
    {
        return a - b;
    }

    public double subtract(double a, double b) 
    {
        return a - b;
    }

    // Multiplication
    public int multiply(int a, int b) 
    {
        return a * b;
    }

    public double multiply(double a, double b) 
    {
        return a * b;
    }

    // Division
    public int divide(int a, int b) 
    {
        if (b == 0) 
        {
            throw new ArithmeticException("Division by zero");
        }
        return a / b;
    }

    public double divide(double a, double b) 
    {
        if (b == 0.0) 
        {
            throw new ArithmeticException("Division by zero");
        }
        return a / b;
    }
}
public class class_QuestionNo17 
{
    public static void main(String[] args) 
    {
        Calculator calc = new Calculator();

        // Addition
        System.out.println("Addition:");
        System.out.println("2 + 3 = " + calc.add(2, 3));
        System.out.println("2.5 + 3.5 = " + calc.add(2.5, 3.5));

        // Subtraction
        System.out.println("\nSubtraction:");
        System.out.println("5 - 3 = " + calc.subtract(5, 3));
        System.out.println("5.5 - 3.3 = " + calc.subtract(5.5, 3.3));

        // Multiplication
        System.out.println("\nMultiplication:");
        System.out.println("2 * 3 = " + calc.multiply(2, 3));
        System.out.println("2.5 * 3.5 = " + calc.multiply(2.5, 3.5));

        // Division
        System.out.println("\nDivision:");
        System.out.println("6 / 3 = " + calc.divide(6, 2));
        System.out.println("7.5 / 2.5 = " + calc.divide(7.5, 2.5));
    }
}


