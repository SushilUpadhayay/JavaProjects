/*
Implement a Java program to find the sum of elements in an integer array.
*/
package Assignment1;
import java.util.Scanner;
public class IO_QuestionNo9 {
    public static void main(String[] args)
    {
        Scanner input = new Scanner(System.in);
        System.out.print("Enter the size of the array: ");
        int count = input.nextInt();
        int[] arr = new int[count]; // Dynamic memory allocation
        
        // to take input from user
        for(int i = 0; i<count; i++)
        {
            System.out.print("Enter "+i+"th element of array: ");
            arr[i]=input.nextInt();
        }
        // To find sum of elements of array
        int sum = 0;
        for(int i = 0; i<count; i++)
        {
            sum = sum + arr[i];
            
        }
        System.out.print("The sum of elements of array is: "+sum);
    }
    
}
