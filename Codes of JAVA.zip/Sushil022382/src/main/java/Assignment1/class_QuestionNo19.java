/*
Create an abstract class Shape with abstract methods calculateArea() and calculatePerimeter().
Implement subclasses Rectangle and Circle that extend Shape and provide concrete
implementations for these methods.
 */
package Assignment1;
// same as question no 3
public class class_QuestionNo19 
{
    
}
