/*
Write a program in Java to explain the use of break and continue statements.
*/
package Assignment1;

public class IO_QuestionNo8 {
    public static void main(String[] args)
    {
        //Let's say I want to print the first 10 numbers(not including 5) from 0 to 100
        int count = 0;
        for(int i = 1; i<100; i++)
        {
            if(count == 10)
            {
                break; // we only need 10 even numbers
            }
            if(i == 5)
            {
                continue;
            }
            System.out.println(i+"\t");
            count++;
        }
    }
    
}
