/*
Define an interface Drawable with a method draw(). Implement classes Circle and Rectangle
that implement this interface and provide their own implementations for the draw() method.
 */
package Assignment1;
// Trailokya Raj Ojha sir said don't do tjis question at this time
public class class_QuestionNo20 {
    
}
