/*
Design a utility class MathHelper with static methods for calculating factorial, finding the square
root, and computing the power of a number.
*/
package Assignment1;
public class Math_helper 
{
    // Method to calculate factorial
    public static int factorial(int n) 
    {
        if (n < 0) 
        {
            throw new IllegalArgumentException("Factorial is not defined for negative numbers");
        }
        int result = 1;
        for (int i = 1; i <= n; i++) 
        {
            result *= i;
        }
        return result;
    }

    // Method to find square root
    public static double squareRoot(double x) 
    {
        if (x < 0) 
        {
            throw new IllegalArgumentException("Square root is not defined for negative numbers");
        }
        return Math.sqrt(x);
    }

    // Method to compute power of a number
    public static double power(double base, double exponent) 
    {
        return Math.pow(base, exponent);
    }

    public static void main(String[] args) 
    {
        // Testing factorial
        System.out.println("Factorial of 5: " + factorial(5));

        // Testing square root
        System.out.println("Square root of 16: " + squareRoot(16));

        // Testing power
        System.out.println("2 raised to the power of 3: " + power(2, 3));
    }
}
