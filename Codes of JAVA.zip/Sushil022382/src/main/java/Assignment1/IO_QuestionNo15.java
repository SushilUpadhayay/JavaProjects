/*
\Write a Java program to concatenate two strings and print the result.
*/
package Assignment1;
import java.util.Scanner;
public class IO_QuestionNo15 {
    public static void main(String[] args)
    {
        Scanner input = new Scanner(System.in);
        
        //Taking input of strings
        System.out.print("Enter first string: ");
        String str1 = input.nextLine();
        System.out.print("Enter second string: ");
        String str2 = input.nextLine();
        StringBuilder stringBuilder = new StringBuilder(); 
        
        //Concatinating strings
        stringBuilder.append(str1); 
        stringBuilder.append(" "); 
        stringBuilder.append(str2); 
        System.out.println("The concatinated string ist: " + stringBuilder.toString()+".");
    }
}
