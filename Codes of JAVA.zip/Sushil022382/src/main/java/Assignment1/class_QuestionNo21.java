/*
Implement a class Outer containing an inner class Inner. Demonstrate how to create an instance
of the inner class from the outer class and from an external class.
*/
package Assignment1;
class Outer 
{
    
    class Inner 
    {
        void display() 
        {
            System.out.println("Inner class method");
        }
    }

    // Method in Outer class to create an instance of Inner class
    void createInnerInstance() 
    {
        Inner inner = new Inner();
        inner.display();
    }
}
public class class_QuestionNo21 
{
    public static void main(String[] args) 
    {
        // Creating an instance of Outer class
        Outer outer = new Outer();

        // Creating an instance of Inner class from Outer class method
        outer.createInnerInstance();

        // Creating an instance of Inner class from an external class
        Outer.Inner inner = outer.new Inner();
        inner.display();
    }
}


