/*
Extend the library example with a Librarian class. Implement a relationship where a library
employs multiple librarians, but a librarian can work in multiple libraries.
*/
package Assignment1;
class Librarian 
{
    private String name;
    private Library[] libraries;
    private int libraryCount;

    public Librarian(String name, int maxLibraries) 
    {
        this.name = name;
        this.libraries = new Library[maxLibraries];
        this.libraryCount = 0;
    }

    public void addLibrary(Library library) 
    {
        if (libraryCount < libraries.length) 
        {
            libraries[libraryCount++] = library;
        }
        else 
        {
            System.out.println("Cannot work in more libraries. Maximum capacity reached.");
        }
    }
    public String getName()
    {
        return name;
    }
    public Library[] getLibraries()
    {
        return libraries;
    }
}
public class class_QuestionNo15
{
    public static void main(String[] args) 
    {
        Library library1 = new Library("Library1", 2);
        Library library2 = new Library("Library2", 2);
        Library library3 = new Library("Library3", 3);
        
        // Create librarians
        Librarian librarian1 = new Librarian("Sushil Upadhayay", 2);
        librarian1.addLibrary(library1);
        librarian1.addLibrary(library2);

        Librarian librarian2 = new Librarian("Aakash Sharma", 2);
        librarian2.addLibrary(library2);
        librarian2.addLibrary(library3);

        // Print information about librarians
        System.out.println("Librarian 1: " + librarian1.getName());
        Library[] libraries1 = librarian1.getLibraries();
        for (Library library : libraries1) 
        {
            System.out.println("- " + library.getName());
        }

        System.out.println("Librarian 2: " + librarian2.getName());
        Library[] libraries2 = librarian2.getLibraries();
        for (Library library : libraries2) 
        {
            System.out.println("- " + library.getName());
        }
    }
}