/*
Create a class BankAccount with private attributes such as account number, balance, and owner
name. Implement getter and setter methods to access and modify these attributes.
*/
package Assignment1;
class BankAccount
{
    private String acc_number, owner_name;
    private double balance;
    BankAccount(String owner_name, String acc_number, double balance)
    {
        this.owner_name = owner_name; // 'this' keyword refers to current instance itself
        this.acc_number = acc_number;
        this.balance = balance;
    }
    
    // Method 1 - Getter
    public String getName()
    { 
        return owner_name;
    }
    
    // Method 2 - Getter
    public String getAccount()
    { 
        return acc_number;
    }
    
    // Method 3 - Getter
    public double getBalance()
    { 
        return balance;
    }
    
    // Method 1 - Setter
    public void setName(String N)
    {
        this.owner_name = N;
    } 
    
    // Method 2 - Setter
    public void setAccount(String N)
    {
        this.acc_number = N;
    } 
    
    // Method 3 - Setter
    public void setBalance(double N)
    {
        this.balance = N;
    }
}

public class class_QuestionNo10 {
     public static void main(String[] args)
    {
        BankAccount B = new BankAccount("Sushil", "04900501206348", 50000000);
        B.setBalance(250000); // Calling setter method 
        
        // calling setter methods
        System.out.println("This account belongs to: "+B.getName()); 
        System.out.println("The account number is: "+B.getAccount());
        System.out.println("This account has balance of: "+B.getBalance());
        
        
    }
    
}
