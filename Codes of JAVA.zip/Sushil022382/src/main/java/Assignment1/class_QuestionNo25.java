/*
Utilize Java streams to process a collection of strings. Perform operations like filtering out strings
containing a specific substring, sorting them alphabetically, and collecting the results into a new
list.
 */
package Assignment1;
import java.util.Arrays;


public class class_QuestionNo25  
{
    public static void main(String[] args) 
    {
        String[] stringArray = {"apple", "banana", "orange", "grape", "kiwi", "pineapple"};
        String substring = "an";
        
        String[] filteredStrings = Arrays.stream(stringArray) //to filter the strings, ChatGpt help
                .filter(s -> s.contains(substring))
                .toArray(String[]::new);

        System.out.println("Filtered and sorted strings containing \"" + substring + "\":");
        for (String str : filteredStrings) 
        {
            System.out.println(str);
        }
    }
}

