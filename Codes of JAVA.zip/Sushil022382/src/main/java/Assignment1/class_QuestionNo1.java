/*
Define a class Car with attributes such as make, model, year, and price. Implement constructors,
getter and setter methods, and demonstrate the creation of multiple Car objects.
 */
package Assignment1;
class Car 
{
    
    String model, year;
    Double price;
    private String name; // Private Member variable of this class. For this attribute getter and setter method are used

    Car(String name, String model, String year, Double price)
    {
        this.name = name; // 'this' keyword refers to current instance itself
        this.model = model;
        this.price = price;
        this.year = year;
    }
    
    // Method 1 - Getter
    public String getName()
    { 
        return name;
    }
    
    // Method 2 - Setter
    public void setName(String N)
    {
        this.name = N;
    } 
    
    //  Method 3 - for displaying attributes of different objects
    public void display()
    {
        System.out.println("The name of the car is: "+this.name+"."); //Automaticallly calls the getter method
        System.out.println("The model of the car is: "+this.model+".");
        System.out.println("The year of the car is: "+this.year+".");
        System.out.println("The price of the car is: "+this.price+" million dollars.");
    }
}
public class class_QuestionNo1 
{
    
    public static void main(String args[])
    {
        
        // creating an object of student
        Car Bugatti = new Car("Bugatti", "Chiron", "2017/02/25", 3.5);
        Car Henessey = new Car("Henessey", "Venom GT", "2005/01/06", 2.5);
        
        // changing the private attribute by invoking setter method
        Bugatti.setName("Toyota");
        
        //Displaying 
        Bugatti.display();
        Henessey.display();
        
    }
}

