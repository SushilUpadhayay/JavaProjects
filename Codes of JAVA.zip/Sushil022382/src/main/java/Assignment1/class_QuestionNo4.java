/*
Create a class Account with two overloaded constructors. First constructor is used for
initializing, name of account holder, account number and initial amount in account. Second
constructor is used for initializing name of account holder, account number, addresses, type of
account and current balance. Account class is having methods Deposit (), Withdraw (), and
Get_Balance().Make necessary assumption for data members and return types of the methods.
Create objects of Account class and use them.
*/
package Assignment1;
class Account
{
    String acc_holder, acc_num;
    double current_bal,initial_amount = 0;
    String address, type_of_acc; 
    
    Account(String acc_holder, String acc_num, double initial_amount)
    {
        this.acc_holder = acc_holder;
        this.acc_num = acc_num;
        this.initial_amount = initial_amount;
    }
    Account(String acc_holder, String acc_num, String address, String type_of_acc, double current_bal)
    {
        this.acc_holder = acc_holder;
        this.acc_num = acc_num;
        this.address = address;
        this.type_of_acc = type_of_acc;
        this.current_bal = current_bal;
    }
    
    public void deposit(double deposit_amount)
    {
        this.current_bal = deposit_amount + this.initial_amount;
        System.out.println("Amount of "+deposit_amount+" is deposited into the account.");
          
    }
    
    public void withdraw(double withdraw_amount)
    {
        if((this.current_bal>withdraw_amount))
        {
            this.current_bal = this.current_bal - withdraw_amount;
            System.out.println("Amount of "+withdraw_amount+" is withdrawn from the account.");
        }
        else
        {
            System.out.println("Insufficient balance!");
        }
  
    }
    
    public void get_balance()
    {
        System.out.println("The total amount in this account is:"+(this.current_bal));  
    }
}

public class class_QuestionNo4 {
    public static void main(String[] args)
    {
        Account a1 = new Account("Sushil", "04900501206347", 500);
        Account a2 = new Account("Aakash", "04900501206347", "Gulariya", "saving", 5012);
        
        a1.deposit(500);
        a1.withdraw(200);
        a1.get_balance();
        
        a2.deposit(50);
        a2.withdraw(5230);
        a2.get_balance();
    }
    
    
}
