/*
 Develop a Java program that defines a method to calculate the factorial of a given number and
use it to find the factorial of 5.
*/
package Assignment1;
import java.util.Scanner;
public class IO_QuestionNo14 {
    public static void main(String[] args)
    {
        Scanner input = new Scanner(System.in);
        System.out.print("Enter a positive integer number: ");
        int num = input.nextInt();
        int fact = 1;
        while(num!=0)
        {
            fact = num*fact;
            num--;        
        }
        System.out.println("The factorial of a given num is "+fact+".");
    }
}
