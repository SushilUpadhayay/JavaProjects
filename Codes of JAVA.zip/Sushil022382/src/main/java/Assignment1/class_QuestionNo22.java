/*
Define an enum type DayOfWeek representing the days of the week. Implement a method in a
separate class that takes a day as input and returns whether it's a weekday or a weekend day.
*/
package Assignment1;

enum DayOfWeek 
{
    MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAY, SUNDAY;
}


class DayClassifier 
{
    public static String classifyDay(DayOfWeek day) 
    {
        return switch (day) 
        {
            case SUNDAY, MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY -> "Weekday";
            case SATURDAY  -> "Weekend";
            default -> "Invalid day";
        };
    }
}

public class class_QuestionNo22 
{
    public static void main(String[] args) 
    {
        // Test the method
        DayOfWeek day1 = DayOfWeek.MONDAY;
        DayOfWeek day2 = DayOfWeek.SATURDAY;
        DayOfWeek day3 = DayOfWeek.WEDNESDAY;

        System.out.println(day1 + " is a " + DayClassifier.classifyDay(day1));
        System.out.println(day2 + " is a " + DayClassifier.classifyDay(day2));
        System.out.println(day3 + " is a " + DayClassifier.classifyDay(day3));
    }
}
