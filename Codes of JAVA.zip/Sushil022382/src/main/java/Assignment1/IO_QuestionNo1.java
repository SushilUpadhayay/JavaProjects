
package Assignment1;

public class IO_QuestionNo1 {
       public static void main(String[] args) {
           // Declarations
        int a; 
        float b;
        char c;
        boolean bol;
        double db;
        long lg;
        byte by;
        
        //Initialization
        
        a = 5;
        b = 6;
        c = 'J';
        bol = true;
        db = 6.3;
        lg = 56;
        by = 2;
        
        System.out.println("Print integer value: "+ a);
        System.out.println("Print float value: "+ b);
        System.out.println("Print character value: "+ c);
        System.out.println("Is bol variable is true or false?: "+ bol);
        System.out.println("Print double datatype value: "+ db);
        System.out.println("Print long datatype value: "+ lg);
        System.out.println("How many bytes are stored in the variable by: "+ by);
        
    
        
    }
}
