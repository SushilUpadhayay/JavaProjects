/*
Write a class Worker and derive classes Daily Worker and Salaried Worker from it. Every worker
is has a name and a salary rate. Write method ComPay( int hours) to compute the week pay of
every worker. A Daily Worker is paid on the basis of number of days s/he work. The Salaried
Worker gets paid the wage for 40 hours a week no matter what actual hours is. Test this
program to calculate the pay of workers. You are expected to use concept of polymorphism to
write this program.
*/
package Assignment1;
abstract class Worker
{
    String name;
    double salary_rate;
    public abstract void ComPay(int hours);
}

class Daily_worker extends Worker
{
    Daily_worker(String name, double salary_rate)
    {
        this.name = name;
        this.salary_rate = salary_rate;
    }
    @Override
    public void ComPay(int hours)
    {
        System.out.println("The total salary of a daily worker "+this.name+" is: "+this.salary_rate*hours); 
    }
}
class Salaried_worker extends Worker
{
    Salaried_worker(String name, double salary_rate)
    {
        this.name = name;
        this.salary_rate = salary_rate;
    }
    @Override
    public void ComPay(int hours)
    {
        if (hours < 40)
        {
            System.out.println("The total salary of the required salaried worker "+this.name+" is: "+this.salary_rate*40);  
        }
        else
        {
            System.out.println("The total salary of the required salaried worker "+this.name+" is: "+this.salary_rate*(hours-40));
        }
        
    }
}

public class class_QuestionNo7 {
    public static void main(String[] args)
    {
        Daily_worker dw = new Daily_worker("Sushil", 123.5);
        dw.ComPay(52);
        
        Salaried_worker sw = new Salaried_worker("Aakash", 115.36);
        sw.ComPay(32);
    }
    
}
