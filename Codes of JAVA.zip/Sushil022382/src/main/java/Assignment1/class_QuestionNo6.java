/*
Write a program in Java to create a Player class. Intermit classes Cricket _Player, Football
_Player and Hockey_ Player from Player class.
*/
package Assignment1;
class Player
{
    String player_name, player_type, address;
    int age, jersey_num;
    double salary;
    
}
class Cricket_player extends Player
{
    double run_rate = 0, over_played = 0, bowling_over = 0;
    int run = 0;
    Cricket_player(String player_name, String player_type, int jersey_num, int age, String address, double salary, double run_rate, double bowling_over, int run)
    {
        this.player_name = player_name;
        this.address = address;
        this. age = age;
        this.salary = salary;
        this.jersey_num = jersey_num;
        this.player_type = player_type;
        this.bowling_over = bowling_over;
        this.run_rate = run_rate; 
        this.run = run;
    }
    public void show_details()
    {
        System.out.println("The details of the required cricket player is as follows: ");
        System.out.println("Name: "+this.player_name);
        System.out.println("Player Type: "+this.player_type);
        System.out.println("Address: "+this.address);
        System.out.println("Jersey Number: "+this.jersey_num);
        System.out.println("Age: "+this.age);
        System.out.println("Salary: "+this.salary);
        System.out.println("Run rate: "+this.run_rate);
        System.out.println("Playing over: "+this.over_played);
        System.out.println("Over Bowling: "+this.bowling_over);
        System.out.println("Runs: "+this.run);
    }
}
class Football_player extends Player
{
    double playing_time = 0;
    int goals = 0, assist = 0;
    Football_player(String player_name, String player_type, int jersey_num, int age, String address, double salary, double playing_time, int goals, int assist)
    {
        this.player_name = player_name;
        this.address = address;
        this. age = age;
        this.salary = salary;
        this.jersey_num = jersey_num;
        this.player_type = player_type;
        this.playing_time = playing_time;
        this.goals = goals;
        this.assist = assist;
    }
    public void show_details()
    {
        System.out.println("The details of the required football player is as follows: ");
        System.out.println("Name: "+this.player_name);
        System.out.println("Address: "+this.address);
        System.out.println("Age: "+this.age);
        System.out.println("Salary: "+this.salary);
        System.out.println("Jersey Number: "+this.jersey_num);
        System.out.println("Player Type: "+this.player_type);
        System.out.println("Time played: "+this.playing_time);
        System.out.println("Goals: "+this.goals);
        System.out.println("Number of assist: "+this.assist);
    }
}
class Hockey_player extends Player
{
    double playing_time = 0;
    int goals = 0, assist = 0;
    Hockey_player(String player_name, String player_type, int jersey_num, int age, String address, double salary, double playing_time, int goals, int assist)
    {
        this.player_name = player_name;
        this.address = address;
        this. age = age;
        this.salary = salary;
        this.jersey_num = jersey_num;
        this.player_type = player_type;
        this.playing_time = playing_time;
        this.goals = goals;
        this.assist = assist;
    }
    public void show_details()
    {
        System.out.println("The details of the required hockey player is as follows: ");
        System.out.println("Name: "+this.player_name);
        System.out.println("Address: "+this.address);
        System.out.println("Age: "+this.age);
        System.out.println("Salary: "+this.salary);
        System.out.println("Jersey Number: "+this.jersey_num);
        System.out.println("Player Type: "+this.player_type);
        System.out.println("Time played: "+this.playing_time);
        System.out.println("Goals: "+this.goals);
        System.out.println("Number of assist: "+this.assist);
    }
}

public class class_QuestionNo6 {
    public static void main(String[] args)
    {
        Cricket_player C1 = new Cricket_player("Sushil Upadhayay", "Allrounder", 07, 23, "Nepal", 2650000, 115.25, 6, 61);
        C1.show_details();
        
        Football_player F1 = new Football_player("Aakash Sharma", " Forward", 03, 21, "Uganda", 5020000, 52, 6, 3);
        F1.show_details();
        
        Hockey_player H1 = new Hockey_player("Robair Aakash", "Stricker", 01, 22, "USA", 503600, 25, 3, 2);
        H1.show_details();
    }
    
}
