/*
Write a Java program to check if a given number is positive, negative, or zero using if-else
statements.
*/
package Assignment1;
import java.util.Scanner;

public class IO_QuestionNo5 {
     public static void main(String[] args)
     {
        Scanner input = new Scanner(System.in);
        System.out.print("Enter a number(must be a number not character, string or boolean): ");
        int num = input.nextInt();
        if(num>0)
        {
            System.out.println("Number is positive.");
        }
        else if(num<0)
        {
            System.out.println("Nuumnber is negative");
        }
        else
        {
            System.out.println("Number is equals to zero.");
        }
        
     }
    
}
