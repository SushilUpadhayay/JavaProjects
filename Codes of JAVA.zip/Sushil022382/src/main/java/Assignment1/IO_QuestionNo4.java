/*
Write a program in Java to implement the formula Width*Area = Height.I think it's Area= Width * Height
*/
package Assignment1;
import java.util.Scanner;

public class IO_QuestionNo4 {
    public static void main(String[] args)
    {
        Scanner input = new Scanner(System.in);
        System.out.print("Enter Width(must be float or integer): ");
        int Width = input.nextInt();
        System.out.print("Enter Height(must be float or integer): ");
        int Height = input.nextInt();
        
        System.out.println("The area is: "+(Width*Height)+" Square Units.");
 
    }
    
}
