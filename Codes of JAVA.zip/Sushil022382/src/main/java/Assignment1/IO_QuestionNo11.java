/*
Implement a java program to print all Armstrong numbers within a specified range.
*/
package Assignment1;
import java.util.Scanner;
public class IO_QuestionNo11 {
    public static void main(String[] args)
    {
        Scanner input = new Scanner(System.in);
        System.out.print("Enter left extreme: ");
        int Lrange = input.nextInt();
        System.out.print("Enter right extreme: ");
        int Rrange = input.nextInt();
        int remainder;
        int result = 0;
        for(int i = Lrange; i<=Rrange; i++)
        {
            int len = (int) (Math.log10(i) + 1); 
            int num = i;
            int original_num = num;
            while(num!=0)
            {
                remainder = num%10;
                num = num/10;
                result = result + (int) Math.pow(remainder, len);
            }
            if( result == original_num && len != 1)
            {
                System.out.println(result);
            }
            result = 0;
        }
    }
}
