/*
Write a Java program to demonstrate type casting between different data types, such as int to
double and vice versa.
*/
package Assignment1;


public class IO_QuestionNo12 {
    public static void main(String[] args)
    {
        int a = 5;
        double db = 6.5;
        double db2 = db;
        db = a;
        System.out.println("Integer value of "+a+" is converted into double value of "+db);  
        a = (int)db2;
        System.out.print("Double value of "+db2+" is converted into integer value of "+a);
    }
}
