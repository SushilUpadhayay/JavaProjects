/*
Write Java program to show that private member of a super class cannot be accessed from
derived classes.
*/
package Assignment1;
class Base
{
    private int a = 5;
}
class Derived extends Base
{
    public void get_data()
    {
        //System.out.println("Private member of base class has value of "+this.a+"."); 
        // the above line of code produces error as we are trying to access private member of base class                                                                         
    }
}
public class class_QuestionNo5 {
    public static void main(String[] args)
    {
        Derived d = new Derived();
        System.out.println("Accessing private member of the base class.");
        d.get_data();
    }
    
}
