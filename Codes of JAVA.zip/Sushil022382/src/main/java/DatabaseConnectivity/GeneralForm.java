
package DatabaseConnectivity;

import java.sql.*;
import java.util.Scanner;
public class GeneralForm{
    public static void main(String[] args) throws Exception{
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Hello", "root", "5130");
            Statement st = con.createStatement();
            String pro;
            System.out.println("Enter program: ");
            Scanner input = new Scanner(System.in);
            pro = input.nextLine();
            String sql = "SELECT * FROM Student WHERE program = '"+pro+"'";
            ResultSet rs = st.executeQuery(sql);
            System.out.println("Details of the students enrolled in"+pro+" program");
            while(rs.next())
            {
                System.out.println("Id: "+ rs.getString("id")+ ","+"Name: "+rs.getString("name"));
            }
            rs.close();
            con.close();
            st.close();       
    }
 
 
}
