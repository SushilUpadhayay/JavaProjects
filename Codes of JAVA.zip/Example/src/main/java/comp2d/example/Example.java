
package comp2d.example;
import java.lang.System;
public class Example {
    public static String reverse(String input) {
        //return new StringBuilder(input).reverse().toString();
        // Create a StringBuilder object with the input string
        StringBuilder stringBuilder = new StringBuilder(input);

        // Reverse the characters in the StringBuilder object
        stringBuilder.reverse();

        // Convert the StringBuilder back to a String and return it
        return stringBuilder.toString();   
    }
    public static void main(String[] args) { 
        // you can replace any string in the "Hello"
        System.out.println(Example.reverse("Hello"));
    }
}
