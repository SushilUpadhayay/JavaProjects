
package comp2d.example;
import java.util.Scanner;
public class Palindrome {
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a string: ");
        String input = sc.nextLine();
        StringBuilder sb = new StringBuilder(input); // Create a StringBuilder object with the input string
        String reversed = sb.reverse().toString(); // Reverse the characters in the StringBuilder object
        if (input.equals(reversed))
        {
            System.out.println("The string is a palindrome.");
        }
        else
        {
            System.out.println("The string is not a palindrome.");
 
        }
    }
}
