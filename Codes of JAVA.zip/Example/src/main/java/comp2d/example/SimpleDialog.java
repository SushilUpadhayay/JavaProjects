package comp2d.example;
import javax.swing.*; 

public class SimpleDialog extends JFrame{ 
    public static void main(String[] args){
        JFrame frame = new JFrame("Main Frame");
        JButton button = new JButton("Open Dialog");
        
        button.addActionListener(e -> {
            JDialog dialog = new JDialog(frame, "Dialog Title", true);
            dialog.add(new JLabel("This is a dialog box"));
            dialog.setSize(200, 100);
            dialog.setVisible(true);
        });

        frame.add(button);
        frame.setSize(400, 200);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
}
// to write this code using awt just import import java.awt.*; and import java.awt.event.*;
// then you are good to go. You don't have to import swing. The code for swing and awt is almost same
// JOptionPane is also a dialog box. Use JOptionPane for quick and standard dialogs that require minimal customization.
// Use JDialog when you need a highly customizable dialog with specific components and layouts, or when creating complex 
// dialogs that JOptionPane cannot accommodate.

/* Dialog using AWT
import java.awt.*;
import java.awt.event.*;

public class SimpleDialog {
    public static void main(String[] args) {
        Frame frame = new Frame("Main Frame");
        Button button = new Button("Open Dialog");

        button.addActionListener(e -> {
            Dialog dialog = new Dialog(frame, "Dialog Title", true);
            dialog.setLayout(new FlowLayout());
            dialog.add(new Label("This is a dialog box"));
            dialog.setSize(200, 100);
            dialog.setVisible(true);
        });

        frame.add(button);
        frame.setSize(400, 200);
        frame.setLayout(new FlowLayout());
        frame.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent we) {
                frame.dispose();
            }
        });
        frame.setVisible(true);
    }
}
*/