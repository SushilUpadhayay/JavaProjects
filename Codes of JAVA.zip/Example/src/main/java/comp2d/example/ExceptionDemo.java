
package comp2d.example;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class ExceptionDemo {

    public static void main(String[] args) {
        // Demonstrate unchecked exception
        try
        {
            System.out.println(10/0);
        } 
        catch (ArithmeticException e) 
        {
            System.out.println("Unchecked Exception: " + e.getMessage());
        }

        // Demonstrate checked exception
        try 
        {
            readFile("nonexistentfile.txt");
        } 
        catch (FileNotFoundException e) 
        {
            System.out.println("Checked Exception: " + e.getMessage());
        }
    }
    // Method that demonstrates a checked exception
    public static void readFile(String filename) throws FileNotFoundException 
    {
        // Create a File object representing the file with the given filename
        File file = new File(filename);
        
        // Create a Scanner object to read the file
        // This line will throw FileNotFoundException if the file does not exist
        Scanner scanner = new Scanner(file);
        
        // Read and print each line of the file until there are no more lines
        while (scanner.hasNextLine())
        {
            System.out.println(scanner.nextLine());
        }
        // Close the Scanner to free up resources
        scanner.close();
    }
}
