
package comp2d.example;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.io.IOException;

public class InetAddressDemo {
    public static void main(String[] args) {
        try {
            // 1. Get InetAddress by hostname
            InetAddress ip = InetAddress.getByName("www.example.com");
            System.out.println("Address by Name: " + ip.getHostAddress());
            System.out.println("Host Name by Name: " + ip.getHostName());
            System.out.println("Is Reachable (5 seconds): " + ip.isReachable(5000));

            // 2. Get all InetAddress objects for a hostname
            InetAddress[] addressesByName = InetAddress.getAllByName("www.example.com");
            System.out.println("\nAll Addresses by Name:");
            for (InetAddress addr : addressesByName) {
                System.out.println("Address: " + addr.getHostAddress() + " | Host Name: " + addr.getHostName());
            }

            // 3. Get the local machine's IP address
            InetAddress localAddress = InetAddress.getLocalHost();
            System.out.println("\nLocal Host Address: " + localAddress.getHostAddress());
            System.out.println("Local Host Name: " + localAddress.getHostName());
    
        } catch (UnknownHostException e) {
            System.err.println("Unknown Host: " + e.getMessage());
        } catch (IOException e) {
            System.err.println("I/O Error: " + e.getMessage());
        }
    }
}

