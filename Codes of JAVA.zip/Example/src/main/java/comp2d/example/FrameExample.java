
package comp2d.example;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class FrameExample extends JFrame {

    private JTextField jTextField1;

    public FrameExample() {
        super("String Operations"); // to set the title of the JFrame
        setLayout(new FlowLayout());

        JLabel jLabel1 = new JLabel("Input String:");
        jTextField1 = new JTextField(20); // 20 means that the textfield has a width that can accomate 20 characters of string

        JButton button1 = new JButton("Check Palindrome");
        JButton button2 = new JButton("Reverse String");
        JButton button3 = new JButton("Extract Vowels");

        /*button1.addActionListener(new ActionListener() { // more traditional way of writing action listner
            @Override
            public void actionPerformed(ActionEvent e) {
                checkPalindrome();
            }
        });*/
        button1.addActionListener(e -> { // action listner using lambda expression
                checkPalindrome();
        });

        button2.addActionListener(new ActionListener() { // ActionListner is an interface
            @Override
            public void actionPerformed(ActionEvent e) {
                reverseString();
            }
        });

        button3.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                extractVowels();
            }
        });

        add(jLabel1);
        add(jTextField1);
        add(button1);
        add(button2);
        add(button3);

        setSize(300, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    private void checkPalindrome() {
        String input = jTextField1.getText();
        StringBuilder sb = new StringBuilder(input);
        String reversed = sb.reverse().toString();
        if (input.equals(reversed)) {
            JOptionPane.showMessageDialog(this, "The string is a palindrome.");
        } else {
            JOptionPane.showMessageDialog(this, "The string is not a palindrome.");
        }
    }

    private void reverseString() {
        String input = jTextField1.getText();
        StringBuilder sb = new StringBuilder(input);
        String reversed = sb.reverse().toString();
        JOptionPane.showMessageDialog(this, "Reversed string: " + reversed);
    }

    private void extractVowels() {
        String input = jTextField1.getText();
        StringBuilder vowels = new StringBuilder();
        for (char c : input.toCharArray()) {
            if ("AEIOUaeiou".indexOf(c) != -1) {
                vowels.append(c);
            }
        }
        JOptionPane.showMessageDialog(this, "Vowels in the string: " + vowels.toString());
    }

    public static void main(String[] args) {
        new FrameExample();
    }
}

