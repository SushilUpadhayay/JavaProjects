
package comp2d.example;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
// this is made with swing not awt
public class NewClass1 extends JFrame{
   private JTextField jTextField1;
   private JLabel jLabel1;
   private JButton jButton1;
   private JButton jButton2;
   private JButton jButton3;
    public NewClass1()
    {
        super("String Operations");
        setLayout(new FlowLayout());
        
        jLabel1 = new JLabel("Input a string:");
        jTextField1 = new JTextField(20);
        
        jButton1 = new JButton("Palindrome");
        jButton2 = new JButton("Reverse");
        jButton3 = new JButton("Vowels");
        
        
        jButton1.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e)
            {
                String str = jTextField1.getText();
                palindrome(str);
            }
        });
        
        jButton2.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                String str = jTextField1.getText();
                reverse(str);
            }    
        });
        jButton3.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                String str = jTextField1.getText();
                vowels(str);
            }    
        });
        
        add(jLabel1);
        add(jTextField1);
        add(jButton1);
        add(jButton2);
        add(jButton3);
        
        setSize(300, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }
    public void palindrome(String str)
    {
        String original = str;
        StringBuilder stb = new StringBuilder(str);
        String dup = stb.reverse().toString();
        if(original.equals(dup))
        {
            JOptionPane.showMessageDialog(this, "Palindrome ");
        }
        else
        {
            JOptionPane.showMessageDialog(this, " Not Palindrome ");
        }
     
    }
    public void reverse(String str)
    {
        StringBuilder stb = new StringBuilder(str);
        String dup = stb.reverse().toString();
        JOptionPane.showMessageDialog(this, " Reverse"+dup);
    }
    public void vowels(String str)
    {
        str = str.toLowerCase();
        int len = str.length();
        char[] ch = str.toCharArray();
        StringBuilder str2 = new StringBuilder();
        for(int i = 0; i<len; i++)
        {
            char c = ch[i];
            if(c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u' )
            {
               str2.append(c);
            }
        }
        JOptionPane.showMessageDialog(this, "Vowels:"+str2.toString());
    }


    public static void main(String[] args)
    {
        new NewClass1();
    }
}
