
import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class DataBaseManipulation extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. 
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet DataBaseManipulation</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet DataBaseManipulation at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");*/
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
        // code to insert data into the database
        try (PrintWriter out = response.getWriter())
        {
            String r = request.getParameter("roll");
            String n = request.getParameter("name");
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/MyDB", "root", "5130");
            Statement st = con.createStatement();
            String str = "INSERT INTO Student(RollNo, Name) Values='"+r+"','"+n+"'";
            st.executeUpdate(str);
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<body>");
            out.println("<h1>Your data is sucessfully inserted into the database</h1>");
            out.println("</body></html>");       
        }
        catch(Exception e)
        {
            System.out.println("Exception: "+e.getMessage());
        }    
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }

}
/* ComboBox in html
Combo Box's Name:<select = name = "a valid Indentifier">
<option>option1</option>
<option>option2</option>
<option>option3</option>
<option>option4</option>
</select>
*/
// When to use get and post method()