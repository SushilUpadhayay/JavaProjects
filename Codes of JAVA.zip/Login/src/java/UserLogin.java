
import jakarta.servlet.RequestDispatcher;
import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.PreparedStatement;

public class UserLogin extends HttpServlet {
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
    }
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
         processRequest(request, response);
        try
        {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ServletLogin","root", "5130");
            String n = request.getParameter("txtName");
            String p = request.getParameter("textPwd");
            String sql = "SELECT * FROM Login WHERE UserName = ? AND Password = ?";
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setString(1, n);
            pst.setString(2, p);

            ResultSet rs = pst.executeQuery();
            if(rs.next())
            {
                // If login is sucessful then user is sent to the welcome page
                RequestDispatcher rd = request.getRequestDispatcher("/welcome.html");
                rd.forward(request, response);
            }
            else
            {
                PrintWriter out = response.getWriter();
                out.println("<!DOCTYPE html>");
                out.println("<html>");
                out.println("<body>");
                out.println("<h1>Login is Unsucessful</h1></body></html>");
            }
            pst.close();
            con.close();
        }
        
        catch(Exception e)
        {
            System.out.println(e.getMessage());
        }
    }
    @Override
    public String getServletInfo() {
        return "Short description";
    }
}
