import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.TilePane;
import javafx.stage.Stage;

public class TilePaneLayout extends Application {
    @Override
    public void start(Stage primaryStage) {
        // Create a TilePane
        TilePane tilePane = new TilePane();

        // Set preferred tile size
        tilePane.setPrefColumns(3); // Set the number of columns
        tilePane.setPrefRows(2); // Set the number of rows

        // Set the horizontal and vertical gaps between the children
        tilePane.setHgap(10);
        tilePane.setVgap(10);

        // Create buttons
        for (int i = 1; i <= 6; i++) {
            Button btn = new Button("Button " + i);
            tilePane.getChildren().add(btn);
        }

        // Create a scene with the TilePane
        Scene scene = new Scene(tilePane, 300, 200);
        primaryStage.setTitle("TilePane Layout Example");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
