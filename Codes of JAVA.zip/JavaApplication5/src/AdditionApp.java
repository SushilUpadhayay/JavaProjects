// Simple program in JavaFX that demonstrates concept of UI controls, Event Handling in JavaFX
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class AdditionApp extends Application {

    @Override
    public void start(Stage primaryStage) {
        // Create GUI components
        Label num1Label = new Label("Number 1:");
        Label num2Label = new Label("Number 2:");
        Label resultLabel = new Label("Result:");

        TextField num1Field = new TextField();
        TextField num2Field = new TextField();
        Label resultDisplay = new Label(); // Since the text field is editable, it is not good to use it for displaying the result

        Button addButton = new Button("Add");

        // Set up event handling
        addButton.setOnAction(event -> {
            try 
            {
                double num1 = Double.parseDouble(num1Field.getText()); // take input from textfield
                double num2 = Double.parseDouble(num2Field.getText()); // take input from textfield
                double result = num1 + num2;
                resultDisplay.setText(String.format("%.2f", result));
            } 
            catch (Exception e)
            {
                resultDisplay.setText("Error: Invalid input");
            }
        });

        // Create layout container
        GridPane gridPane = new GridPane();
        
        // Set gaps between rows and columns
        gridPane.setHgap(10);
        gridPane.setVgap(10);
        
        // Add buttons to the GridPane
        gridPane.add(num1Label, 0, 0);
        gridPane.add(num1Field, 1, 0); // column 1, row 0
        gridPane.add(num2Label, 0, 1);
        gridPane.add(num2Field, 1, 1);
        gridPane.add(addButton, 0, 2); // Span button across two columns
        gridPane.add(resultLabel, 0, 3);
        gridPane.add(resultDisplay, 1, 3);
        
        // Create a scene with the GridPane
        Scene scene = new Scene(gridPane, 300, 200);
        primaryStage.setTitle("Addition Calculator");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
