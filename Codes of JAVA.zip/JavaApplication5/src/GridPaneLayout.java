
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class GridPaneLayout extends Application {
    @Override
    public void start(Stage primaryStage) {
        // Create a GridPane
        GridPane root = new GridPane();
        
        // Create buttons
        Button btn1 = new Button("Button 1");
        Button btn2 = new Button("Button 2");
        Button btn3 = new Button("Button 3");
        Button btn4 = new Button("Button 4");
        Button btn5 = new Button("Button 5");
        Button btn6 = new Button("Button 6");

        // Add buttons to the GridPane
        root.add(btn1, 0, 0); // column=0, row=0
        root.add(btn2, 1, 0); // column=1, row=0
        root.add(btn3, 0, 1); // column=0, row=1
        root.add(btn4, 1, 1); // column=1, row=1
        root.add(btn5, 0, 2); // column=0, row=2
        root.add(btn6, 1, 2); // column=1, row=2

        // Set gaps between rows and columns
        root.setHgap(10); // Horizontal gap
        root.setVgap(10); // Vertical gap

        // Create a scene with the GridPane
        Scene scene = new Scene(root, 300, 250);
        primaryStage.setTitle("GridPane Layout");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}

