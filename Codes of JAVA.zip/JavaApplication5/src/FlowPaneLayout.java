import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.FlowPane;
import javafx.stage.Stage;

public class FlowPaneLayout extends Application {
    @Override
    public void start(Stage primaryStage) {
        // Create a FlowPane
        FlowPane flowPane = new FlowPane();

        // Create of multiple buttons
        // you can also explicitely create multiple button in the same way as previous layouts
        // but creation of multiple button in this way is much faster and makes the code smaller
        for (int i = 1; i <= 10; i++) {
            Button btn = new Button("Button " + i);
            flowPane.getChildren().add(btn);
        }

        // Set the horizontal and vertical gaps between the children
        flowPane.setHgap(10);
        flowPane.setVgap(10);

        // Create a scene with the FlowPane
        Scene scene = new Scene(flowPane, 300, 200);
        primaryStage.setTitle("FlowPane Layout Example");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
