import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
public class BorderPaneLayout extends Application {
    @Override
    public void start(Stage primaryStage) {
        Button btn1 = new Button("Btn1"); // We can also directly set the text of the during creation of button
        Button btn2 = new Button();
        Button btn3 = new Button();
        Button btn4 = new Button();
        Button btn5 = new Button();
        
        // btn1.setText("Btn 1");
        btn2.setText("Btn 2");
        btn3.setText("Btn 3");
        btn4.setText("Btn 4");
        btn5.setText("Btn 5");
        
        btn1.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                System.out.println("Button 1 clicked");
            }
        });
        
        btn2.setOnAction(event ->{
            System.out.println("Button 2 is clicked");
        });
        
        btn3.setOnAction(event ->{
            System.out.println("Button 3 is clicked");
        });
        
        btn4.setOnAction(event ->{
            System.out.println("Button 4 is clicked");
        });
        btn5.setOnAction(event ->{
            System.out.println("Button 5 is clicked");
        });
        
        
        BorderPane root = new BorderPane();
        root.setTop(btn1); // Place btn1 at the top
        root.setBottom(btn2); // Place btn2 at the bottom
        root.setLeft(btn3); // Place btn3 on the left
        root.setRight(btn4); // Place btn4 on the right
        root.setCenter(btn5); // Place btn4 on the right
        
        Scene scene = new Scene(root, 300, 250);
        primaryStage.setTitle("BorderPane Layout");
        primaryStage.setScene(scene);
        primaryStage.show();
    }
    public static void main(String[] args) {
        launch(args);
    }  
}

