import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

public class HBoxLayout extends Application {
    @Override
    public void start(Stage primaryStage) {
        Button btn1 = new Button();
        Button btn2 = new Button();
        Button btn3 = new Button();
        Button btn4 = new Button();
        
        btn1.setText("Btn 1");
        btn2.setText("Btn 2");
        btn3.setText("Btn 3");
        btn4.setText("Btn 4");
        btn1.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                System.out.println("Button 1 clicked");
            }
        });
        
        btn2.setOnAction(event ->{
            System.out.println("Button 2 is clicked");
        });
        
        btn3.setOnAction(event ->{
            System.out.println("Button 3 is clicked");
        });
        
        btn4.setOnAction(event ->{
            System.out.println("Button 4 is clicked");
        });
                 
        HBox root = new HBox();
        root.getChildren().add(btn1);
        root.getChildren().add(btn2);
        root.getChildren().add(btn3);
        root.getChildren().add(btn4);
        Scene scene = new Scene(root, 200, 100);
        primaryStage.setTitle("HBox Layout");
        primaryStage.setScene(scene);
        primaryStage.show();
    }
    public static void main(String[] args) {
        launch(args);
    }  
}
