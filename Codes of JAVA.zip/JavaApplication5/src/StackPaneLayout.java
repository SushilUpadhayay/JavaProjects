import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

public class StackPaneLayout extends Application {
    @Override
    public void start(Stage primaryStage) {
        // Create a StackPane
        StackPane stackPane = new StackPane();

        // Create buttons
        Button btn1 = new Button("Button 1");
        Button btn2 = new Button("Button 2");
        Button btn3 = new Button("Button 3");

        // Add buttons to the StackPane
        stackPane.getChildren().addAll(btn1, btn2, btn3);

        // Set alignments if needed (optional)
        StackPane.setAlignment(btn1, javafx.geometry.Pos.TOP_LEFT);
        StackPane.setAlignment(btn2, javafx.geometry.Pos.CENTER);
        StackPane.setAlignment(btn3, javafx.geometry.Pos.BOTTOM_RIGHT);

        // Create a scene with the StackPane
        Scene scene = new Scene(stackPane, 300, 250);
        primaryStage.setTitle("StackPane Layout Example");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
/*
If you don't set explicit alignments for the children of a StackPane, all children will be centered by default. 
This means that each child node will be placed in the center of the StackPane, and they will overlap each other. 
The last child added will be on top of the stack. You can try this by commenting the lines 22, 23 and 24
*/