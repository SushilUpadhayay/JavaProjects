
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
/*
These import statements bring in the necessary classes from the JavaFX library. Application is the base class for JavaFX applications, 
ActionEvent and EventHandler handle events, Scene represents the container for all content, Button is a control element, StackPane is a 
layout component, and Stage represents the primary window.
*/
public class NewFXMain extends Application {
    
    @Override
    public void start(Stage primaryStage) { // The start method is overridden from the Application class. 
                                            // It is the main entry point for JavaFX applications. 
                                            // primaryStage is the main window of the application.
        Button btn = new Button(); // Creates a new Button object.
        btn.setText("Say 'Hello World'"); // Sets the text displayed on the button to "Say 'Hello World'".
        btn.setOnAction(event -> { // event handling using lambda expression 
            System.out.println("Hello World!"); // prints hello world on console whenever button is clicked
        });
        
        StackPane hlo = new StackPane(); // Creates a StackPane layout manager. StackPane lays out its children in a back-to-front stack.
                                          // In our case we want the button at the middle that's why we use this layout
        
        hlo.getChildren().add(btn); // Adds the button to the StackPane.
        
        Scene scene = new Scene(hlo, 300, 250); // It's like JPanel in the Swing
        
        primaryStage.setTitle("Sushil Upadhayay"); // Sets the title of the primary stage (main window) to "Hello World!".
        primaryStage.setScene(scene); // Adds scene to the stage
        primaryStage.show(); // make stage visible
    }
    public static void main(String[] args) {
        launch(args); // It calls launch, which starts the JavaFX application.
    }
    
}
// Primary Stage = Frame
// Scene = Panel of the Frame on which we added components. Unlike Swing where you have a option to add componenets directly onto the main 
// frame meaning not using panel in the frame to add componets, JavaFX needs Scene.
/*btn.setOnAction(new EventHandler<ActionEvent>() { 
            @Override
            public void handle(ActionEvent event) {
                System.out.println("Hello World!");
            }
}); Event can also be handled this way
*/




